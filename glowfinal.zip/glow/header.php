<?php
include "php/database.php";
$database = new Database();
$page_name = explode('/',$_SERVER['SCRIPT_NAME'])[2];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title>GLOW</title>
    <link rel="stylesheet" href="assets/CSS/normalize.css"/>
    <link rel="stylesheet" href="assets/CSS/all.min.css"/>
    <link rel="stylesheet" href="assets/CSS/bootstrap.min.css"/>
    <link rel="stylesheet" href="assets/CSS/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/CSS/newStyle.css"/>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com"/>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet"/>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="assets/CSS/sweetalert.css"/>
    <script src="assets/JavaScript/sweetalert.min.js"></script>
    <style>
        .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            margin: 3vh;
        }

        .toggle-password i {
            font-size: 18px;
        }
        .toggle-password1 {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            margin: 3vh;
        }

        .toggle-password1 i {
            font-size: 18px;
        }

    </style>

    <script>
        function showpassword () {
            let passwordInput = $(".toggle-password").prev('.password-input');
            if (passwordInput.attr('type') === 'password') {
                passwordInput.attr('type', 'text');
                $(".toggle-password").addClass('fa-eye-slash').removeClass('fa-eye');
            } else {
                passwordInput.attr('type', 'password');
                $(".toggle-password").addClass('fa-eye').removeClass('fa-eye-slash');
            }
            console.log('here');
        };
        function showpassword1 () {
            let passwordInput = $(".toggle-password1").prev('.password-input1');
            if (passwordInput.attr('type') === 'password') {
                passwordInput.attr('type', 'text');
                $(".toggle-password1").addClass('fa-eye-slash').removeClass('fa-eye');
            } else {
                passwordInput.attr('type', 'password');
                $(".toggle-password1").addClass('fa-eye').removeClass('fa-eye-slash');
            }
            console.log('here');
        };
    </script>
</head>
<body <?php if($page_name=='signin.php'||$page_name=='signup-art.php'||$page_name=='signup-cust.php'){echo 'style="background-color: #efe7e5; background-image: none"';} ?>>
<?php if(isset($_SESSION['success'])){ ?>
    <script>
        swal("<?= $_SESSION['success'] ?>");
    </script>
<?php } unset($_SESSION['success']); ?>
<!-- Start Header -->
<nav class="navbar fixed-top navbar-expand-lg p-3">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">
            <img src="assets/Images/logo3-1.png" alt="Bootstrap" width="150" height=""/>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav" style="flex-grow: 0">
            <ul class="navbar-nav">
                <li class="nav-item fs-5">
                    <a class="nav-link <?= $page_name=='index.php'?'active':'' ?>" aria-current="page" href="index.php">Home
                    </a>
                </li>
                <li class="nav-item fs-5">
                    <a class="nav-link <?= $page_name=='FAQ.php'?'active':'' ?>" href="FAQ.php">F.A.Q</a>
                </li>
                <li class="nav-item fs-5">
                    <a class="nav-link <?= $page_name=='services.php'?'active':'' ?>" href="services.php">Services</a>
                </li>
                <?php if(!isset($_SESSION['id'])){ ?>
                    <li class="nav-item fs-5">
                        <a class="nav-link <?= $page_name=='signin.php'?'active':'' ?>" href="signin.php">Sign in</a>
                    </li>
                    <li class="nav-item fs-5 dropdown">
                        <a class="nav-link <?= $page_name=='signup-cust.php'||$page_name=='signup-art.php'?'active':'' ?> dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Sign up
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="signup-cust.php">Customer</a></li>
                            <li><a class="dropdown-item" href="signup-art.php">Services Provider</a></li>
                        </ul>
                    </li>
                <?php }else{ ?>
                    <li class="nav-item fs-5 dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fa-solid fa-user"></i>
                            Welcome <?= $_SESSION['name'] ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="Customer/customer-account.php">Account Info</a></li>
                            <li><a class="dropdown-item" href="php/logout.php">Log Out</a></li>
                        </ul>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>
<!-- End Header -->
