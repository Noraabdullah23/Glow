</div>
</div>


<script src="../assets/JavaScript/all.min.js"></script>
<script src="../assets/JavaScript/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
<script src="../assets/JavaScript/script.js"></script>
<script>
    $(document).ready(function () {
        $('#example').DataTable();
    });
    $(document).ready(function () {
        $('#example1').DataTable();
    });
</script>
</body>
</html>