<?php include "header.php";
$id = $_SESSION['id'];
$reservations = $database->Select("select * from reservations WHERE serviceProviderId = '$id'");
?>
    <!-- Start Service Provider reserv     -->
    <section class="artist w-100" style="padding: 0;">
        <div class="container-fluid p-0"
             style="display: flex; flex-direction: column; align-items: center; justify-content: center;min-height: 100vh;padding-top: 3rem;">
            <div class="row">
                <div class="title">
                    <h1 class="test-color">Customer Reservations</h1>
                </div>
            </div>
            <div class="row mt-3 mb-2" style="width: 85%!important">
                <table id="example" class="table table-striped" style="width:100%;">
                    <thead>
                    <tr class="test-color">
                        <th style="text-align: center;">Reservations Number</th>
                        <th style="text-align: center;">Reservation Details</th>
                        <th style="text-align: center;">Control</th>
                    </tr>
                    </thead>
                    <tbody class="test-color">
                    <?php if (!empty($reservations)) {
                        foreach ($reservations as $reservation) { ?>
                            <tr>
                                <td class="fs-5"><h4 class="test-color"><?= $reservation['id'] ?></h4></td>
                                <td class="test-color" style="text-align: center;">
                                    <button class="btn btn-outline-success test-color"
                                            onclick="open_reservatinDetails(<?= $reservation['id'] ?>)">Reservation
                                        Details
                                        <i class="fa-solid fa-exclamation"></i>
                                    </button>
                                </td>
                                <td class="text-center">
                                    <?php if($reservation['status']==0){ ?>
                                        <button class="btn btn-outline-success test-color" onclick="Accept(<?= $reservation['id'] ?>)">
                                            Accept
                                            <i class="fa-regular fa-circle-check"></i>
                                        </button>
                                        <button class="btn btn-outline-danger test-color" onclick="Refuse(<?= $reservation['id'] ?>)">
                                            Refuse
                                            <i class="fa-regular fa-circle-xmark"></i>
                                        </button>
                                    <?php }else if($reservation['status']==1){echo 'Accepted';}else{echo 'Refused';} ?>

                                </td>
                            </tr>
                        <?php }
                    } ?>
                    </tbody>
                </table>
            </div>
            <!--Start footer  -->
            <div class="footer w-100">
                <div class="container-fluid d-flex justify-content-center">
                    <p>Copyright &copy; 2023 GLOW</p>
                </div>
            </div>
            <!--End footer  -->

        </div>

    </section>
    <!-- End Service Provider reserv-->
    <!-- Modal For  -->
    <div class="modal fade" id="reservatinDetails" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
         aria-labelledby="reservatinDetailsLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="reservatinDetailsLabel">Booking Details</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">Client Name:</label>
                        <p class="m-0" id="client_name"></p>
                    </div>
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">Service Name:</label>
                        <p class="m-0" id="service_name"></p>
                    </div>
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">How Many Client:</label>
                        <p class="m-0" id="clients_number"></p>
                    </div>
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <p class="m-0" style="padding-left: 10px;" id="type"></p>
                    </div>
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">Date and Time:</label>
                        <span id="datetime"></span>
                    </div>
                </div>
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Invoice Details</h1>
                </div>
                <div class="modal-body">
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">Total Amount (SAR):</label>
                        <p class="m-0" id="price"></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php include "footer.php"; ?>
<script>
    function open_reservatinDetails(id) {
        $.ajax({
            type: "get",
            url: "../php/customer/reservations.php",
            data: {id:id},
            success: function(data) {
                $('#service_name').text('');
                data=JSON.parse(data)[0];
                if(data['type'])
                    var service = JSON.parse(data['service_name']);

                $('#client_name').text(data['client_name']);
                $('#type').text(data['type']);
                $('#clients_number').text(data['clients_number']);
                $('#datetime').text(data['datetime']);
                $('#price').text(data['totalPrice']);
                for (let i =0;i<service.length;i++)
                    $('#service_name').append(service[i]+',');
                $('#reservatinDetails').modal('show');
            }
        });
    }
    function Accept(id) {
        swal({title:'Are You Sure To Accept ?',
                showCancelButton: true,
                confirmButtonText: "Yes",
                cancelButtonText: "No",
            },
            function (result) {
                if(result)
                    window.location.href="../php/serviceProvider/reservations.php?accept="+id;
            }
        )
    }
    function Refuse(id) {
        swal({title:'Are You Sure To Refuse ?',
                showCancelButton: true,
                confirmButtonText: "Yes",
                cancelButtonText: "No",
            },
            function (result) {
                if(result)
                    window.location.href="../php/serviceProvider/reservations.php?refuse="+id;
            }
        )
    }
</script>
