<?php
include "../php/database.php";
$database = new Database();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <!-----Css-->
    <title>GLOW</title>
    <link rel="stylesheet" href="../assets/CSS/normalize.css"/>
    <link rel="stylesheet" href="../assets/CSS/all.min.css"/>
    <link rel="stylesheet" href="../assets/CSS/bootstrap.min.css"/>
    <link rel="stylesheet" href="../assets/CSS/newStyle.css"/>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com"/>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700&display=swap"
          rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="../assets/CSS/dash.css">
    <link rel="stylesheet" type="text/css" href="../assets/CSS/sweetalert.css"/>
    <script src="../assets/JavaScript/sweetalert.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


    <!----- Box icons csss------>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            margin-right: 3vh;
        }

        .toggle-password i {
            font-size: 18px;
        }
        .toggle-password1 {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            margin-right: 3vh;
        }

        .toggle-password1 i {
            font-size: 18px;
        }

    </style>

    <script>
        function showpassword () {
            let passwordInput = $(".toggle-password").prev('.password-input');
            if (passwordInput.attr('type') === 'password') {
                passwordInput.attr('type', 'text');
                $(".toggle-password").addClass('fa-eye-slash').removeClass('fa-eye');
            } else {
                passwordInput.attr('type', 'password');
                $(".toggle-password").addClass('fa-eye').removeClass('fa-eye-slash');
            }
            console.log('here');
        };
        function showpassword1 () {
            let passwordInput = $(".toggle-password1").prev('.password-input1');
            if (passwordInput.attr('type') === 'password') {
                passwordInput.attr('type', 'text');
                $(".toggle-password1").addClass('fa-eye-slash').removeClass('fa-eye');
            } else {
                passwordInput.attr('type', 'password');
                $(".toggle-password1").addClass('fa-eye').removeClass('fa-eye-slash');
            }
            console.log('here');
        };
    </script>
</head>

<body>
<?php if(isset($_SESSION['success'])){ ?>
    <script>
        swal("<?= $_SESSION['success'] ?>");
    </script>
<?php } unset($_SESSION['success']); ?>
<div class="all">
    <div class="container-fluid show-side" style="padding-right: 0;">
        <nav class="sidebar close">
            <header>
                <div class="image-text">
                        <span class="image">
                            <img src="../assets/Images/logo3.png" alt="logo">
                        </span>
                </div>
                <i class='bx bx-chevron-right toggle'></i>
            </header>
            <div class="menu-bar">
                <div class="menu">
                    <ul class="menu-links" style="padding-left: 0;">
                        <li class="nav-item">
                            <i class="fa-solid fa-user icon"></i>
                            <span class="text nav-text">WELECOME <Span><?= $_SESSION['name'] ?></Span></span>
                        </li>
                        <li class="nav-link">
                            <a href="ServiceProvider-home.php">
                                <i class='bx bx-home icon'></i>
                                <span class="text nav-text">Home</span>
                            </a>
                        </li>
                        <li class="nav-link">
                            <a href="ServiceProvider-account.php">
                                <i class='bx bxs-user-account icon'></i>
                                <span class="text nav-text">My Account</span>
                            </a>
                        </li>
                        <li class="nav-link">
                            <a href="ServiceProvider-Reserv.php">
                                <i class='bx bx-user-check icon'></i>
                                <span class="text nav-text">Customer Reservations</span>
                            </a>
                        </li>
                        <li class="">
                            <a href="../php/logout.php">
                                <i class='bx bx-log-out icon'></i>
                                <span class="text nav-text">Logout</span>
                            </a>
                        </li>
                        <li class="mode">
                            <div class="moon-sun">
                                <i class='bx bx-moon icon moon'></i>
                                <i class='bx bx-sun icon sun'></i>
                            </div>
                            <span class="mode-text text">Dark Mode</span>
                            <div class="toggle-switch">
                                <span class="switch"></span>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
