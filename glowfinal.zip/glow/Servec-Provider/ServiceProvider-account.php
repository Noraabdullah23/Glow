<?php include "header.php";
?>
    <section class="account w-100" style="padding: 0;">
        <div class="container" style="min-height: 100vh; display: flex; flex-direction: column;">
            <div class="row">
                <div class="title">
                    <h1 class="test-color">My Account</h1>
                </div>
            </div>
            <div class="row">
                <div class="col d-flex justify-content-center">
                    <div class="card w-75 all-content mb-3">
                        <div class="card-body pt-3">
                            <!-- Bordered Tabs -->
                            <ul class="nav nav-tabs nav-tabs-bordered">
                                <li class="nav-item eoverview">
                                    <button class="nav-link active" data-bs-toggle="tab"
                                            data-bs-target="#profile-overview">Overview
                                    </button>
                                </li>
                                <li class="nav-item eprofile">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">
                                        Edit Profile
                                    </button>
                                </li>
                            </ul>
                            <div class="tab-content pt-2">
                                <div class="tab-pane fade show active profile-overview" id="profile-overview">
                                    <h5 class="card-title ">Profile Details:</h5>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label ">User Name:</div>
                                        <div class="col-lg-9 col-md-8"><?= $_SESSION['username'] ?></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label ">Full Name:</div>
                                        <div class="col-lg-9 col-md-8"><?= $_SESSION['name'] ?></div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Provider ID:</div>
                                        <div class="col-lg-9 col-md-8"><?= $_SESSION['id'] ?></div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Email:</div>
                                        <div class="col-lg-9 col-md-8"><?= $_SESSION['email'] ?></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Phone Number</div>
                                        <div class="col-lg-9 col-md-8"><?= $_SESSION['phone'] ?></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Social Account</div>
                                        <div class="col-lg-9 col-md-8"><?= $_SESSION['instaAccount'] ?></div>
                                    </div>
                                </div>
                                <div class="tab-pane fade profile-edit pt-3" id="profile-edit">
                                    <!-- Profile Edit Form -->
                                    <form action="../php/serviceProvider/profile.php" method="post" enctype="multipart/form-data">
                                        <div class="row mb-3">
                                            <label for="ID" class="col-md-4 col-lg-3 col-form-label">Provider
                                                ID</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="id" type="number" class="form-control" id="ID"
                                                       value="<?= $_SESSION['id'] ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="" class="col-md-4 col-lg-3 col-form-label">Full Name</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="name" type="text" class="form-control" id="" value="<?= $_SESSION['name'] ?>"
                                                       required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="" class="col-md-4 col-lg-3 col-form-label">User Name</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="username" type="text" class="form-control" id="#" value="<?= $_SESSION['username'] ?>"
                                                       required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="email"
                                                   class="col-md-4 col-lg-3 col-form-label">Email</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="email" type="email" class="form-control" id="email"
                                                       value="<?= $_SESSION['email'] ?>"
                                                       required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="" class="col-md-4 col-lg-3 col-form-label">Insta
                                                Account</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="instaAccount" type="text" class="form-control" id="#"
                                                       value="<?= $_SESSION['instaAccount'] ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="" class="col-md-4 col-lg-3 col-form-label">Snap
                                                Account</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="snapAccount" type="text" class="form-control" id="#"
                                                       value="<?= $_SESSION['snapAccount'] ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="" class="col-md-4 col-lg-3 col-form-label">Whatsapp
                                                Account</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="whatsappAccount" type="text" class="form-control" id="#"
                                                       value="<?= $_SESSION['whatsappAccount'] ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="Phone"
                                                   class="col-md-4 col-lg-3 col-form-label">Phone</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="phone" type="tel" maxlength="10" minlength="10" pattern="\d*" class="form-control" id="Phone"
                                                       value="<?= $_SESSION['phone'] ?>" required>
                                            </div>
                                        </div>

                                        <div class="row mb-3" style="position: relative">
                                            <label for="password"
                                                   class="col-md-4 col-lg-3 col-form-label">Password</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input type="password" name="password" class="form-control password-input"
                                                       id="password" >
                                                <i id="eye" onclick="showpassword()" class="toggle-password fa fa-eye"></i>
                                                <input type="hidden" name="oldPassword" value="<?= $_SESSION['password']?>">
                                            </div>
                                        </div>
                                        <div class="row mb-3" style="position: relative">
                                            <label for="c_password" class="col-md-4 col-lg-3 col-form-label">Confirm
                                                Password</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input type="password" name="c_password" class="form-control password-input1"
                                                       id="c_password" >
                                                <i id="eye" onclick="showpassword1()" class="toggle-password1 fa fa-eye"></i>
                                            </div>
                                        </div>
                                        <br>
                   <div class="mb-3">
                    <h5 class="mt-0">Specialization:</h5>
                    <div class="form-check d-flex justify-content-center  gap-2" style="flex-direction: column;" >
                    <div>
                        <input class="form-check-input" name="specialization[]"  type="checkbox" <?php if(in_array('Makeupartist',$_SESSION['specialization'])){echo 'checked';}  ?> value="Makeupartist" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                            Makeupartist
                        </label>
                    </div>
                        <ul>
                            <li class="mb-2"><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 126px">Bride</span>
                                <input type="number" min="0" value="<?= $_SESSION['price']->Makeupartist->Bride ?>" name="price[Makeupartist][Bride]"  class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>
                            <li class=""><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 126px">Ordinary</span>
                                <input type="number" min="0" value="<?= $_SESSION['price']->Makeupartist->Ordinary ?>" name="price[Makeupartist][Ordinary]"  class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>                            
                        </ul>

                    </div>
                    <div class="form-check d-flex justify-content-center  gap-2" style="flex-direction: column;" >
                    <div>
                        <input class="form-check-input" name="specialization[]"  type="checkbox" <?php if(in_array('Hairstylest',$_SESSION['specialization'])){echo 'checked';}  ?> value="Hairstylest" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                            Hairstylest
                        </label>
                    </div>
                        <ul>
                            <li class="mb-2"><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 126px">Bride</span>
                                <input type="number" min="0" value="<?= $_SESSION['price']->Hairstylest->Bride ?>" name="price[Hairstylest][Bride]"  class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>
                            <li class=""><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 126px">Ordinary</span>
                                <input type="number" min="0" value="<?= $_SESSION['price']->Hairstylest->Ordinary ?>" name="price[Hairstylest][Ordinary]"  class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>                            
                        </ul>

                    </div>
                    <div class="form-check d-flex justify-content-center  gap-2" style="flex-direction: column;" >
                    <div>
                        <input class="form-check-input" name="specialization[]"  type="checkbox" <?php if(in_array('Spa',$_SESSION['specialization'])){echo 'checked';}  ?> value="Spa" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                            Spa
                        </label>
                    </div>
                        <ul>
                            <li class="mb-2"><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 126px">Nails</span>
                                <input type="number" min="0" value="<?= $_SESSION['price']->Spa->Nails ?>" name="price[Spa][Nails]" class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>
                            <li class="mb-2"><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 126px">Moroccan bath</span>
                                <input type="number" min="0" value="<?= $_SESSION['price']->Spa->Moroccan_bath ?>" name="price[Spa][Moroccan_bath]" class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>
                                <li class=""><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 126px">Massage</span>
                                <input type="number" min="0" value="<?= $_SESSION['price']->Spa->Massage ?>" name="price[Spa][Massage]" class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>                             
                        </ul>

                    </div>                  
                </div>
                                        <div class="text-center">
                                            <button type="submit" name="update" class="btn btn-secondary">Save Changes</button>
                                        </div>
                                    </form><!-- End Profile Edit Form -->
                                </div>
                            </div><!-- End Bordered Tabs -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Start footer  -->
        <div class="footer">
            <div class="container-fluid d-flex justify-content-center">
                <p>Copyright &copy; 2023 GLOW</p>
            </div>
        </div>
        <!--End footer  -->
    </section>
<?php include "footer.php"; ?>