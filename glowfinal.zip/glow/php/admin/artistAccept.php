<?php
include "../database.php";
$database = new Database();

if(isset($_GET['accept'])){
    $id = $_GET['accept'];
    $update = $database->Update("Update service_provider set accepted = 1 WHERE id = '$id'");
    $_SESSION['success'] = "Artist has been accepted successfully";
    header('location:../../admin/Admin-ArtistAccount.php');
}
else if(isset($_GET['refuse'])){
    $id = $_GET['refuse'];
    $update = $database->Update("Update service_provider set accepted = 2 WHERE id = '$id'");
    $_SESSION['success'] = "Artist has been refused successfully";
    header('location:../../admin/Admin-ArtistAccount.php');
}