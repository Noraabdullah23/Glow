<?php
include('database.php');
$database = new Database();

if (isset($_POST['loginBtn'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "select * from admin where username = '$username' AND password = '$password'";
    $admin = $database->Select($query);


    $query = "select * from customer where username = '$username' AND password = '$password'";
    $customer = $database->Select($query);


    $query = "select * from `service_provider` where username = '$username' AND password = '$password'";
    $service_provider = $database->Select($query);

    if (!empty($admin)) {
        $_SESSION['id'] = $admin[0]['id'];
        $_SESSION['name'] = $admin[0]['name'];
        $_SESSION['username'] = $admin[0]['username'];
        $_SESSION['email'] = $admin[0]['email'];
        $_SESSION['password'] = $admin[0]['password'];
        $_SESSION['user_type']='admin';
        header('location:../Admin/Admin-home.php');
    }
    else if(!empty($customer)){
        $_SESSION['id'] = $customer[0]['id'];
        $_SESSION['name'] = $customer[0]['name'];
        $_SESSION['username'] = $customer[0]['username'];
        $_SESSION['email'] = $customer[0]['email'];
        $_SESSION['phone'] = $customer[0]['phone'];
        $_SESSION['password'] = $customer[0]['password'];
        $_SESSION['user_type']='customer';

        $date = date('Y-m-d h:i:A');
        $id = $customer[0]['id'];
        $insertInHistoryTable = $database->Insert("INSERT INTO `login_history`(`customer_id`, `login_date`) VALUES ('$id','$date')");

        header('location:../index.php');
    }
    else if(!empty($service_provider)){
        if($service_provider[0]['accepted']==1) {
            $_SESSION['id'] = $service_provider[0]['id'];
            $_SESSION['name'] = $service_provider[0]['name'];
            $_SESSION['username'] = $service_provider[0]['username'];
            $_SESSION['phone'] = $service_provider[0]['phone'];
            $_SESSION['email'] = $service_provider[0]['email'];
            $_SESSION['password'] = $service_provider[0]['password'];
            $_SESSION['instaAccount'] = $service_provider[0]['instaAccount'];
            $_SESSION['snapAccount'] = $service_provider[0]['snapAccount'];
            $_SESSION['whatsappAccount'] = $service_provider[0]['whatsappAccount'];
            $_SESSION['scope'] = $service_provider[0]['scope'];
            $_SESSION['dayFrom'] = $service_provider[0]['dayFrom'];
            $_SESSION['dayTo'] = $service_provider[0]['dayTo'];
            $_SESSION['timeFrom'] = $service_provider[0]['timeFrom'];
            $_SESSION['timeTo'] = $service_provider[0]['timeTo'];
            $_SESSION['cardName'] = $service_provider[0]['cardName'];
            $_SESSION['accountNumber'] = $service_provider[0]['accountNumber'];
            $_SESSION['iban'] = $service_provider[0]['iban'];
            $_SESSION['specialization'] = json_decode($service_provider[0]['specialization']);
            $_SESSION['price'] = json_decode($service_provider[0]['price']);
            $_SESSION['user_type'] = 'service_provider';
            header('location:../Servec-Provider/ServiceProvider-home.php');
        }else if($service_provider[0]['accepted']==0)
        {
            $_SESSION['success'] = "Please wait till admin approval";
            header('location:../signin.php');
        }
        else if($service_provider[0]['accepted']==2)
        {
            $_SESSION['success'] = "Your request to join has been refused by admin";
            header('location:../signin.php');
        }
    }
    else {
        $_SESSION['success'] = "Invalid User Name Or Password";
        header('location:../signin.php');
    }

}
?>