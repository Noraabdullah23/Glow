<?php
include('database.php');
$database = new Database();

if (isset($_POST['registerCustomer'])) {

    $name = $_POST['name'];
    $username = $_POST['username'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['c_password'];

    $duplicatedUserName = $database->Select("select * from `customer` WHERE username = '$username'");
    if (!empty($duplicatedUserName)) {
        $_SESSION['success'] = "this username is already in use";
        header('location:../signup-cust.php');
    } else if ($confirmPassword != $password) {
        $_SESSION['success'] = "Password doesn't match";
        header('location:../signup-cust.php');
    } else {
        $result = $database->Insert("INSERT INTO `customer`(`name`, `username`, `email`, `phone`, `password`)
                                                  VALUES ('$name','$username','$email','$phone','$password')");
        $_SESSION['success'] = "Registration done you can login now !";
        header('location:../signin.php');
    }
}
if (isset($_POST['registerServiceProvider'])) {

    $name = $_POST['name'];
    $username = $_POST['username'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['c_password'];
    $instaAccount = $_POST['instaAccount'];
    $snapAccount = $_POST['snapAccount'];
    $whatsappAccount = $_POST['whatsappAccount'];
    $scope = json_encode($_POST['scope']);
    $dayFrom = $_POST['dayFrom'];
    $dayTo = $_POST['dayTo'];
    $timeFrom = date('h:i A', strtotime($_POST['timeFrom']));
    $timeTo = date('h:i A', strtotime($_POST['timeTo']));
    $cardName = $_POST['cardName'];
    $accountNumber = $_POST['accountNumber'];
    $iban = $_POST['iban'];
    $specialization = json_encode($_POST['specialization']);
    $price = $_POST['price'];

    $price = json_encode($price);

    $duplicatedUserName = $database->Select("select * from `service_provider` WHERE username = '$username'");
    if (!empty($duplicatedUserName)) {
        $_SESSION['success'] = "this username is already in use";
        header('location:../signup-art.php');
    } else if ($confirmPassword != $password) {
        $_SESSION['success'] = "Password doesn't match";
        header('location:../signup-art.php');
    } else {
        $result = $database->Insert("INSERT INTO `service_provider`(`name`, `username`, `phone`, `email`, `password`, `instaAccount`, `snapAccount`,`whatsappAccount`, `scope`, `dayFrom`, `dayTo`, `timeFrom`, `timeTo`, `cardName`, `accountNumber`, `iban`, `specialization`,`price`)
                                                                VALUES ('$name','$username','$phone','$email','$password','$instaAccount','$snapAccount','$whatsappAccount','$scope','$dayFrom','$dayTo','$timeFrom','$timeTo','$cardName','$accountNumber','$iban','$specialization','$price')");
        $_SESSION['success'] = "Registration done please wait till admin approval";
        header('location:../signin.php');
    }
}
