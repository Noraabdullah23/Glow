<?php
include "../database.php";
$database = new Database();
if(isset($_POST['book'])) {

    $serviceProviderId = $_POST['serviceProviderId'];
    $specialization = $_POST['specialization'];
    $client_name = $_POST['client_name'];
    $service_name = json_encode($_POST['service_name']);
    $clients_number = $_POST['clients_number'] ?? 1;
    $type = $_POST['type'];
    $datetime = date('Y-m-d', strtotime($_POST['datetime']));
    $datetime.=' ';
    $datetime.=date('h:i A',strtotime($_POST['time']));
    $cardHolderName = $_POST['cardHolderName'];
    $cardNumber = $_POST['cardNumber'];
    $expireDate = $_POST['expireDate'];
    $CVV = $_POST['CVV'];
    $totalPrice = $_POST['totalPrice'];
    $customer_id = $_SESSION['id'];

    $checkReservations = $database->Select("select * from reservations WHERE serviceProviderId = '$serviceProviderId' AND datetime = '$datetime'");

    if(empty($checkReservations)) {
        $insert = $database->Insert("INSERT INTO `reservations`(`serviceProviderId`,`customer_id`, `client_name`, `service_name`, `clients_number`, `type`, `datetime`, `cardHolderName`, `cardNumber`, `expireDate`, `CVV`, `totalPrice`) 
                                                          VALUES ('$serviceProviderId','$customer_id','$client_name','$service_name','$clients_number','$type','$datetime','$cardHolderName','$cardNumber','$expireDate','$CVV','$totalPrice')");
        $_SESSION['success'] = "Your Reservation has been done";
        header('location:../../Customer/customer-Reserv.php');
    }else
    {
        $_SESSION['success'] = "This date is reserved before you can choose another date and time";
        header('location:../../Customer/booking.php?specialization='.$specialization.'&price='.$totalPrice.'&serviceId='.$serviceProviderId);
    }

}