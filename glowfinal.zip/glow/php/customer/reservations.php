<?php
include "../database.php";
$database = new Database();
if(isset($_GET['id']))
{
    $id = $_GET['id'];
    $reservation = $database->Select("SELECT p.name,p.email,p.phone,s.* from reservations as s , service_provider as p WHERE p.id = s.serviceProviderId AND s.id = '$id'");
    echo json_encode($reservation);
}