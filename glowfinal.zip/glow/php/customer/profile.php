<?php
include "../database.php";
$database = new Database();
if(isset($_POST['update']))
{
    $id = $_POST['id'];
    $name= $_POST['name'];
    $username= $_POST['username'];
    $phone= $_POST['phone'];
    $email= $_POST['email'];
    $password= $_POST['password'];
    $oldPassword= $_POST['oldPassword'];
    $confirmPassword= $_POST['c_password'];

    if($username!=$_SESSION['username']){
        $duplicatedUserName = $database->Select("select * from `customer` WHERE username = '$username'");
    }
    else
        $duplicatedUserName='';

    if(!empty($duplicatedUserName))
    {
        $_SESSION['success'] = "this username is already in use";
        header('location:../../Customer/customer-account.php');
    }
    else if ($confirmPassword != $password) {
        $_SESSION['success'] = "Password doesn't match";
        header('location:../../Customer/customer-account.php');
    }
    else {

        if (empty($password))
            $password = $oldPassword;

        $result = $database->Update("UPDATE `customer` SET `name`='$name',`username`='$username',`email`='$email',`phone`='$phone',`password`='$password' WHERE id = '$id'");
        $_SESSION['name'] = $name;
        $_SESSION['username'] = $username;
        $_SESSION['email'] = $email;
        $_SESSION['phone'] = $phone;
        $_SESSION['password'] = $password;
        $_SESSION['success'] = "Your Profile has been updated successfully!";
        header('location:../../Customer/customer-account.php');
    }
}