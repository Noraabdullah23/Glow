<?php
include "../database.php";
$database = new Database();
if(isset($_POST['addRate']))
{
    $customer_id = $_SESSION['id'];
    $comment = $_POST['comment'];
    $rate = $_POST['rate'];
    $reservation_id = $_POST['reservation_id'];
    $serviceProviderId = $_POST['serviceProviderId'];

    $insert = $database->Insert("INSERT INTO `reviews`(`reservation_id`, `comment`, `rate`,`serviceProviderId`, `customer_id`)
                                                      VALUES ('$reservation_id','$comment','$rate','$serviceProviderId','$customer_id')");
    $_SESSION['success']='Review has been added successfully';
    header('location:../../Customer/customer-reviw.php');
}