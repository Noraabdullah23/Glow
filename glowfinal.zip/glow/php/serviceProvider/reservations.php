<?php
include "../database.php";
$database = new Database();

if(isset($_GET['accept'])){
    $id = $_GET['accept'];
    $update = $database->Update("Update reservations set status = 1 WHERE id = '$id'");
    $_SESSION['success'] = "Reservation has been accepted successfully";
    header('location:../../Servec-Provider/ServiceProvider-Reserv.php');
}
else if(isset($_GET['refuse'])){
    $id = $_GET['refuse'];
    $update = $database->Update("Update reservations set status = 2 WHERE id = '$id'");
    $_SESSION['success'] = "Reservation has been refused successfully";
    header('location:../../Servec-Provider/ServiceProvider-Reserv.php');
}