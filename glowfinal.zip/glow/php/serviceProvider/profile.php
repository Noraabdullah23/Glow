<?php
include "../database.php";
$database = new Database();
if(isset($_POST['update']))
{
    $id = $_POST['id'];
    $name= $_POST['name'];
    $username= $_POST['username'];
    $phone= $_POST['phone'];
    $email= $_POST['email'];
    $instaAccount= $_POST['instaAccount'];
    $snapAccount = $_POST['snapAccount'];
    $whatsappAccount = $_POST['whatsappAccount'];
    $password= $_POST['password'];
    $oldPassword= $_POST['oldPassword'];
    $confirmPassword= $_POST['c_password'];
    $specialization = json_encode($_POST['specialization']);
    $price = json_encode($_POST['price']);

    if($username!=$_SESSION['username']){
        $duplicatedUserName = $database->Select("select * from `service_provider` WHERE username = '$username'");
    }
    else
        $duplicatedUserName='';

    if(!empty($duplicatedUserName))
    {
        $_SESSION['success'] = "this username is already in use";
        header('location:../../Servec-Provider/ServiceProvider-account.php');
    }
    else if ($confirmPassword != $password) {
        $_SESSION['success'] = "Password doesn't match";
        header('location:../../Servec-Provider/ServiceProvider-account.php');
    }
    else {

        if (empty($password))
            $password = $oldPassword;
        
        $result = $database->Update("UPDATE `service_provider` SET `name`='$name',`username`='$username',`email`='$email',`instaAccount`='$instaAccount',`snapAccount`='$snapAccount',`whatsappAccount`='$whatsappAccount',`phone`='$phone',`specialization`='$specialization',`price`='$price',`password`='$password' WHERE id = '$id'");
        $_SESSION['name'] = $name;
        $_SESSION['username'] = $username;
        $_SESSION['email'] = $email;
        $_SESSION['instaAccount'] = $instaAccount;
        $_SESSION['snapAccount'] = $snapAccount;
        $_SESSION['whatsappAccount'] = $whatsappAccount;
        $_SESSION['phone'] = $phone;
        $_SESSION['password'] = $password;
        $_SESSION['specialization'] = json_decode($specialization);
        $_SESSION['price'] = json_decode($price);
        $_SESSION['success'] = "Your Profile has been updated successfully!";
        header('location:../../Servec-Provider/ServiceProvider-account.php');
    }
}