<?php include "header.php"; ?>
<!-- Start Section Service -->
<section class="service">
    <div class="container">
        <div class="title">
            <h1>Our Services</h1>
        </div>
        <div class="row">
            <div class="col-md-4 col-sm-6 mb-3">
                <div class="card">
                    <img src="assets/Images/icon1-1.png" class="card-img-top" alt="..."/>
                    <div class="card-body">
                        <h4 class="card-title">Makeupartist</h4>
                        <p class="card-text">Doing Makeup</p>
                        <a href="serviceDetails.php?specialization=Makeupartist" class="btn" style="background-color: #bf978f; border: none">Select</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 mb-3">
                <div class="card">
                    <img src="assets/Images/icon2-2.png" class="card-img-top" alt="..."/>
                    <div class="card-body">
                        <h4 class="card-title">Hairstylest</h4>
                        <p class="card-text">Doing Hair</p>
                        <a href="serviceDetails.php?specialization=Hairstylest" class="btn" style="background-color: #bf978f; border: none">Select</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 mb-3">
                <div class="card">
                    <img src="assets/Images/icon3-3.png" class="card-img-top" alt="..."/>
                    <div class="card-body">
                        <h4 class="card-title">Spa</h4>
                        <p class="card-text">Doing Spa</p>
                        <a href="serviceDetails.php?specialization=Spa" class="btn" style="background-color: #bf978f; border: none">Select</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Section Service -->

<!--Start footer  -->
<div class="footer">
    <div class="container-fluid d-flex justify-content-center">
        <p>Copyright &copy; 2023 GLOW</p>
    </div>
</div>
<!--End footer  -->

<script src="assets/JavaScript/all.min.js"></script>
<script src="assets/JavaScript/bootstrap.bundle.min.js"></script>
</body>
</html>
