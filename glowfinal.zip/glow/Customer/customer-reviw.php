<?php include "header.php";
$id = $_SESSION['id'];
$Reviews = $database->Select("select s.*,p.name,p.id as provider_id from service_provider as p, reservations as s left JOIN reviews as r on s.id = r.reservation_id WHERE p.id = s.serviceProviderId AND r.reservation_id IS NULL AND s.customer_id ='$id'");
$oldReviews = $database->Select("select r.*,p.name from reviews as r,reservations as s , service_provider as p WHERE r.reservation_id = s.id AND s.serviceProviderId = p.id AND r.customer_id = '$id'");
?>
<style>
    .rate {
        float: left;
        height: 46px;
        padding: 0 1px;
    }
    .rate:not(:checked) > input {
        position:absolute;
        visibility:hidden;
    }
    .rate:not(:checked) > label {
        float:right;
        width:1em;
        overflow:hidden;
        white-space:nowrap;
        cursor:pointer;
        font-size:30px;
        color:#ccc;
    }
    .rate:not(:checked) > label:before {
        content: '★ ';
    }
    .rate > input:checked ~ label {
        color: #212529;
    }
    .rate:not(:checked) > label:hover,
    .rate:not(:checked) > label:hover ~ label {
        color: #212529;
    }
    .rate > input:checked + label:hover,
    .rate > input:checked + label:hover ~ label,
    .rate > input:checked ~ label:hover,
    .rate > input:checked ~ label:hover ~ label,
    .rate > label:hover ~ input:checked ~ label {
        color: #212529;
    }
</style>
<!-- Start Service Provider reserv     -->
<section class="artist w-100" style="padding: 0;">
    <div class="container-fluid p-0"
         style="display: flex; flex-direction: column; align-items: center; justify-content: center;min-height: 100vh;padding-top: 3rem;">
        <div class="row">
            <div class="title mt-1">
                <h1 class="test-color">Customer Reviews</h1>
            </div>
        </div>
        <div class="row mt-3" style="width: 85%!important">
            <div class="title-rev mb-3">
                <h3 class="test-color">Add Review</h3>
            </div>
            <table class="test-color" id="example" class="table table-striped" style="width:100%;">
                <thead>
                <tr>
                    <th style="text-align: center;">Reservations Number</th>
                    <th style="text-align: center;">Service Provider Name</th>
                    <th style="text-align: center;">Add Reviews</th>
                </tr>
                </thead>
                <tbody>
                <?php if (!empty($Reviews)) {
                    foreach ($Reviews as $review) { ?>
                        <tr>
                            <td class="fs-5"><?= $review['id'] ?></td>
                            <td class="fs-5"><?= $review['name'] ?></td>
                            <td style="text-align: center;">
                                <?php if($review['status']==1){ ?>
                                <button class="btn btn-outline-success test-color" onclick="open_addRateModal(<?= $review['id'] ?>,<?= $review['provider_id'] ?>)">Add Reviews
                                    <i class='bx bx-comment'></i>
                                </button>
                            <?php }else if($review['status']==2){echo 'Refused';}else{echo 'Pending';} ?>
                            </td>
                        </tr>
                    <?php }
                } ?>
                </tbody>
            </table>
        </div>
        <div class="row mt-3 mb-2" style="width: 85%!important">
            <div class="title-rev mb-3">
                <h3 class="test-color">Old Reviews</h3>
            </div>
            <table class="test-color" id="example1" class="table table-striped" style="width:100%;">
                <thead>
                <tr>
                    <th style="text-align: center; width:20% ;">Reservations Number</th>
                    <th style="text-align: center; width:21% ;">Service Provider Name</th>
                    <th style="text-align: center;">Comments</th>
                    <th style="text-align: center; width:15% ;">Rating</th>
                </tr>
                </thead>
                <tbody>
                    <?php if(!empty($oldReviews)){foreach ($oldReviews as $review){?>
                        <tr>
                            <td class="fs-5"><?= $review['reservation_id']?></td>
                            <td class="fs-5"><?= $review['name'] ?></td>
                            <td class="fs-5"><?= $review['comment'] ?></td>
                            <td class="fs-5" style="text-align: center;">
                                <div class="social-icons">
                                    <?php
                                        $rateValue= $review['rate'];
                                        for($i = 1; $i<=5;$i++){
                                            if($i<=$rateValue)
                                                echo '<i class="fas fa-star"> </i>';
                                            else
                                                echo '<i class="far fa-star"> </i>';

                                        }
                                    ?>
                                </div>
                            </td>
                        </tr>
                    <?php } } ?>
                </tbody>
            </table>
        </div>
    </div>
    <!--Start footer  -->
    <div class="footer">
        <div class="container-fluid d-flex justify-content-center">
            <p>Copyright &copy; 2023 GLOW</p>
        </div>
    </div>
    <!--End footer  -->
</section>

<!-- End Service Provider reserv-->
<!-- Modal For  -->
<div class="modal fade" id="addRateModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
     aria-labelledby="addRateModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="addRateModalLabel">Add Review</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="../php/customer/addRate.php" method="post">

                <div class="modal-body">
                    <div class="mb-3">
                        <label for="exampleFormControlTextarea1" class="form-label">Add Comment</label>
                        <textarea class="form-control" name="comment" id="exampleFormControlTextarea1"
                                  rows="3"></textarea>
                        <input type="hidden" id="reservation_id" name="reservation_id">
                        <input type="hidden" id="provider_id" name="serviceProviderId">
                    </div>
                    <label for="exampleFormControlInput1" class="form-label text-start">Add Rating</label>
                    <div class="mb-3">
                        <div class="rate">
                            <input type="radio"  id="star1" name="rate" value="5"/>
                            <label  for="star1" title="text">5 stars</label>
                            <input type="radio"  id="star2" name="rate" value="4"/>
                            <label  for="star2" title="text">4 stars</label>
                            <input type="radio"  id="star3" name="rate" value="3"/>
                            <label  for="star3" title="text">3 stars</label>
                            <input type="radio"  id="star4" name="rate" value="2"/>
                            <label  for="star4" title="text">2 stars</label>
                            <input type="radio"  id="star5" name="rate" value="1"/>
                            <label  for="star5" title="text">1 star</label>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-secondary" name="addRate">Add</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include "footer.php"; ?>
<script>
    function open_addRateModal(id,provider_id) {
        $('#reservation_id').val(id);
        $('#provider_id').val(provider_id);
        $('#addRateModal').modal('show');
    }
</script>
