<?php include "header.php";
$id = $_SESSION['id'];
$reservations = $database->Select("select * from reservations WHERE customer_id = '$id'");
?>
    <section class="artist w-100" style="padding: 0;">
        <div class="container-fluid p-0"
             style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; padding-top: 3rem;">
            <div class="row">
                <div class="title">
                    <h1 class="test-color">My Reservations</h1>
                </div>
            </div>
            <div class="row mt-3 mb-2" style="width: 85%!important">
                <table class="test-color" id="example" class="table table-striped" style="width:100%;">
                    <thead>
                    <tr>
                        <th  class="test-color" style="text-align: center;">Reservations Number</th>
                        <th  class="test-color" style="text-align: center;">Status</th>
                        <th  class="test-color" style="text-align: center;">Reservation Details</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if (!empty($reservations)) {
                        foreach ($reservations as $reservation) { ?>
                            <tr class="test-color">
                                <td class="fs-5 test-color"><?= $reservation['id'] ?></td>
                                <td class="fs-5 test-color">
                                    <?php if($reservation['status']==0){echo 'Pending';}else if($reservation['status']==1){echo 'Accepted';}else{echo 'Refused';} ?>
                                </td>
                                <td style="text-align: center;">
                                    <button class="btn btn-outline-success test-color"
                                            onclick="open_reservatinDetails(<?= $reservation['id'] ?>)">Reservation
                                        Details
                                        <i class="fa-solid fa-exclamation"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php }
                    } ?>
                    </tbody>
                </table>
            </div>
            <!--Start footer  -->
            <div class="footer w-100">
                <div class="container-fluid d-flex justify-content-center">
                    <p>Copyright &copy; 2023 GLOW</p>
                </div>
            </div>
            <!--End footer  -->
        </div>
    </section>
    <!-- End Service Provider reserv-->


    <!-- Modal For  -->
    <div class="modal fade" id="reservatinDetails" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
         aria-labelledby="reservatinDetailsLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="reservatinDetailsLabel">Providers Details</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">Provider Name:</label>
                        <p class="m-0" id="name"></p>
                    </div>
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">Email:</label>
                        <p class="m-0" id="email"></p>
                    </div>
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">Mobil:</label>
                        <p class="m-0" id="phone"></p>
                    </div>
                </div>
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="reservatinDetailsLabel">Booking Details</h1>
                </div>
                <div class="modal-body">
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">Client Name:</label>
                        <p class="m-0" id="client_name"></p>
                    </div>
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">Service Name:</label>
                        <p class="m-0" id="service_name"></p>
                    </div>
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">How Many Client:</label>
                        <p class="m-0" id="clients_number"></p>
                    </div>
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <p class="m-0" style="padding-left: 10px;" id="type"></p>
                    </div>
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">Date and Time:</label>
                        <span id="datetime"></span>
                    </div>
                </div>
                <div class="modal-header">
                    <h1 class="modal-itle fs-5" id="reservatinDetailsLabel">Invoice Details</h1>
                </div>
                <div class="modal-body">
                    <div class="mb-3 d-flex gap-2 align-items-center">
                        <label for="exampleInputEmail1" class="form-label "></label>
                        <label style="font-weight: bold" for="exampleInputEmail1" class="form-label m-0">Total Amount (SAR):</label>
                        <p class="m-0" id="price" ></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php include "footer.php"; ?>
<script>
    function open_reservatinDetails(id) {
        $.ajax({
            type: "get",
            url: "../php/customer/reservations.php",
            data: {id:id},
            success: function(data) {
                $('#service_name').text('');
                data=JSON.parse(data)[0];
                if(data['type'])
                    var service = JSON.parse(data['service_name']);

                $('#name').text(data['name']);
                $('#email').text(data['email']);
                $('#phone').text(data['phone']);
                $('#client_name').text(data['client_name']);
                $('#type').text(data['type']);
                $('#clients_number').text(data['clients_number']);
                $('#datetime').text(data['datetime']);
                $('#price').text(data['totalPrice']);
                for (let i =0;i<service.length;i++)
                    $('#service_name').append(service[i]+',');
                $('#reservatinDetails').modal('show');
            }
        });
    }
</script>
