<?php
include "../php/database.php";
$database = new Database();
$specialization = $_GET['specialization'];
$serviceProviderID = $_GET['serviceId'];
$service = $database->Select("select * from service_provider WHERE id = '$serviceProviderID'")[0];
$prices = json_decode($service['price']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title>GLOW</title>
    <link rel="stylesheet" href="../assets/CSS/normalize.css"/>
    <link rel="stylesheet" href="../assets/CSS/all.min.css"/>
    <link rel="stylesheet" href="../assets/CSS/bootstrap.min.css"/>
    <link rel="stylesheet" href="../assets/CSS/newStyle.css"/>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com"/>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
    <link
            href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700&display=swap"
            rel="stylesheet"
    />
    <link rel="stylesheet" type="text/css" href="../assets/CSS/sweetalert.css"/>
    <script src="../assets/JavaScript/sweetalert.min.js"></script>
</head>
<body style="background-color: #efe7e5; background-image: none">
<?php if(isset($_SESSION['success'])){ ?>
    <script>
        swal("<?= $_SESSION['success'] ?>");
    </script>
<?php } unset($_SESSION['success']); ?>
<!-- Start Header -->
<nav class="navbar fixed-top navbar-expand-lg p-3">
    <div class="container-fluid">
        <a class="navbar-brand" href="../index.php">
            <img src="../assets/Images/logo3-1.png" alt="Bootstrap" width="150" height=""/>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav" style="flex-grow: 0">
            <ul class="navbar-nav">
                <li class="nav-item fs-5">
                    <a class="nav-link" aria-current="page" href="../index.php">Home
                    </a>
                </li>
                <li class="nav-item fs-5">
                    <a class="nav-link" href="../FAQ.php">F.A.Q</a>
                </li>
                <li class="nav-item fs-5">
                    <a class="nav-link" href="../services.php">Servise</a>
                </li>
                <li class="nav-item fs-5 dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                       aria-expanded="false">
                        <i class="fa-solid fa-user"></i>
                        Welcome <?= $_SESSION['name'] ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="../Customer/customer-account.php">Account Info</a></li>
                        <li><a class="dropdown-item" href="../php/logout.php">Log Out</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- End Header -->
<!-- Start Section Booking  -->
<section class="book mb-5">
    <div class="container">
        <div class="row">
            <div class="title">
                <h4>Book Appointment</h4>
            </div>
            <form action="../php/customer/book.php" method="post">
                <input type="hidden" name="serviceProviderId" value="<?= $serviceProviderID ?>">
                <input type="hidden" name="specialization" value="<?= $specialization ?>">
                <div class="booking">
                    <div class="mb-3">
                        <label style="font-weight: 500" for="exampleInputEmail1" class="form-label">Client Name:</label>
                        <input type="text" class="form-control" required name="client_name" value="<?= $_SESSION['name'] ?>" aria-describedby="emailHelp" placeholder="client name"/>
                    </div>
                    <?php if($specialization!='Spa'){?>
                        <div class="mb-3">
                            <label for="" class="form-label" style="font-weight: 500">Service Name:</label><br/>
                            <input type="checkbox" id="bride" onclick="checkBride()" name="service_name[]" value="bride"/>
                            <label class="me-1" for="bride">Bride</label>
                            <span><span>(</span><?= $prices->$specialization->Bride ?> <span>SAR)</span></span> <br>
                            <input type="checkbox" id="ordinary" onclick="checkOrdinary()" name="service_name[]" value="ordinary"/>
                            <label for="ordinary">Ordinary</label>
                            <span><span>(<span id="ordinaryPrice" ><?= $prices->$specialization->Ordinary ?> </span><span>SAR)</span></span>
                            <br/>
                            <label class="mt-3" for="quantity">If you Choose (Ordinary) how many client:</label><br/>
                            <input class="w-100 mt-1 p-1" type="number" readonly id="quantity" name="clients_number" min="1" max="5"/><br/>
                        </div>
                    <?php }else{ ?>
                        <div class="mb-3">
                            <label for="" class="form-label" style="font-weight: 500">Services Name:</label><br />
                            <input type="checkbox" id="nails" onclick="checkNails()" name="service_name[]" value="Nails" />
                            <label class="me-1" for="nails">Nails</label>
                            <span><span>(</span><?= $prices->$specialization->Nails  ?> <span> SAR)</span></span> <br>
                            <input type="checkbox" id="moroco" onclick="checkMoroco()" name="service_name[]" value="Moroco bath" />
                            <label for="moroco">Moroco bath</label>
                            <span><span>(</span> <?= $prices->$specialization->Moroccan_bath ?>  <span> SAR)</span></span>
                            <br />
                            <input type="checkbox" id="mass" onclick="checkMassage()" name="service_name[]" value="Massage" />
                            <label class="me-1" for="mass">Massage</label><span><span>(</span><?= $prices->$specialization->Massage?> <span>SAR)</span></span><br />
                        </div>
                    <?php } ?>
                    <div class="mb-3">
                        <?php $scope = json_decode($service['scope']);
                        $in = in_array('in',$scope);
                        $ex = in_array('ex',$scope);
                        if ($in) { ?>
                            <input type="radio" id="in" name="type" required value="Internal"/>
                            <label class="me-1" for="in">Internal</label>
                        <?php } if ($ex) { ?>
                            <input type="radio" id="out" name="type" required value="External"/>
                            <label for="out">External</label><br/>
                        <?php } ?>

                    </div>
                    <div class="mb-3">
                        <label for="birthdaytime">(date and time of reservation)</label><br/>
                        <input class="w-50 mt-1 p-1" type="text" required id="birthdaytime" name="datetime"/>
                        <input class="w-30 mt-1 p-1" type="time" min="<?= date('H:i',strtotime($service['timeFrom'])) ?>" max="<?= date('H:i',strtotime($service['timeTo'])) ?>" required id="" name="time"/>
                    </div>
                </div>
                <div class="title mt-4">
                    <h4>Make a payment</h4>
                </div>
                <div class="booking">
                    <div class="mb-3">
                        <input type="text" class="form-control" name="cardHolderName" required aria-describedby="emailHelp" placeholder="Credit card number" maxlength="16" minlength="15"/>
                    </div>
                    <div class="mb-3">
                        <input type="text" class="form-control" name="cardNumber" required aria-describedby="emailHelp" placeholder="Name of the card holder"/>
                    </div>
                    <div class="mb-3 d-flex align-items-center">
                        <label for="exampleInputEmail1" class="form-label me-2 mb-0">Expiry Date:</label>
                        <input type="date" class="form-control w-50" name="expireDate" required aria-describedby="emailHelp"/>
                    </div>
                    <div class="mb-3 d-flex align-items-center">
                        <label for="exampleInputEmail1" class="form-label me-2 mb-0">Security Code:</label>
                        <input type="text" class="form-control w-50" name="CVV" required aria-describedby="emailHelp" minlength="3" maxlength="3"/>
                    </div>
                    <div class="mb-3 d-flex align-items-center">
                        <label for="exampleInputEmail1" class="form-label me-2 mb-0">Total Cost Amount (SAR):</label>
                        <span id="totalPrice">0</span>
                        <input type="hidden" name="totalPrice" id="inputTotalPrice" value="">
                    </div>
                </div>
                <button type="submit" name="book" class="btn btn-primary w-100 sub mt-2" style="background-color: #bf978f; border: none">
                    Pay
                </button>
            </form>
        </div>
    </div>
</section>
<!-- End Section Log in -->
<!-- Include jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Include jQuery UI -->
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<!--Start footer  -->
<div class="footer">
    <div class="container-fluid d-flex justify-content-center">
        <p>Copyright &copy; 2023 GLOW</p>
    </div>
</div>
<!--End footer  -->
<script>
    var days = {'Sunday':0, 'Monday':1, 'Tuesday':2, 'Wednesday':3, 'Thursday':4, 'Friday':5, 'Saturday':6};

    $("#birthdaytime").datepicker({
        beforeShowDay: function (d) {
            var day = d.getDay();
            return [day>=days['<?= $service["dayFrom"] ?>']&&day<=days['<?= $service["dayTo"] ?>']];
        },
        minDate: new Date()
    });

    function checkBride() {
        var bride = document.querySelector("#bride");
        var bridePrice = <?= $prices->$specialization->Bride?? 0 ?>;
        var totalPrice = document.querySelector('#totalPrice');
        var totalPriceInteger = parseInt(totalPrice.innerHTML, 10);

        if (bride.checked) {
            totalPriceInteger += bridePrice;
        }
        else
            totalPriceInteger -= bridePrice;

        document.getElementById('totalPrice').innerHTML = totalPriceInteger;
        document.getElementById('inputTotalPrice').value = totalPriceInteger;

    }
    function checkOrdinary() {
        var totalPrice = document.querySelector('#totalPrice');
        var totalPriceInteger = parseInt(totalPrice.innerHTML, 10);

        var ordinary = document.querySelector("#ordinary");
        var ordinaryPrice = <?= $prices->$specialization->Ordinary ?? 0 ?>;
        if (ordinary.checked) {
            totalPriceInteger += ordinaryPrice;
            document.querySelector("#quantity").readOnly = false;
        }
        else {
            totalPriceInteger -= (ordinaryPrice*document.getElementById('quantity').value);
            document.querySelector("#quantity").readOnly = true;
            document.getElementById('quantity').value = 1;
            document.querySelector('#ordinaryPrice').innerHTML = ordinaryPrice;
        }
        document.getElementById('totalPrice').innerHTML = totalPriceInteger;
        document.getElementById('inputTotalPrice').value = totalPriceInteger;
    }

    const input = document.querySelector("#quantity");
    let previousValue = input.value;

    input.addEventListener("input", function() {
        var CurrentPrice = <?= $prices->$specialization->Ordinary ?? 0 ?>;
        var totalPrice = document.querySelector('#totalPrice');
        var totalPriceInteger = parseInt(totalPrice.innerHTML,10);

        var ordinaryPrice = document.querySelector('#ordinaryPrice');
        var ordinaryPriceInteger = parseInt(ordinaryPrice.innerHTML,10);

        if (input.value > previousValue) {
            if(input.value!=1){
                totalPriceInteger+=CurrentPrice;
                ordinaryPriceInteger+=CurrentPrice;
            }
        } else if (input.value < previousValue) {
            totalPriceInteger-=CurrentPrice;
            ordinaryPriceInteger-=CurrentPrice;
        }
        previousValue = input.value;
        document.getElementById('ordinaryPrice').innerHTML=ordinaryPriceInteger;
        document.getElementById('totalPrice').innerHTML=totalPriceInteger;
        document.getElementById('inputTotalPrice').value=totalPriceInteger;
    });

    function checkNails() {
        var nails = document.querySelector("#nails");
        var nailsPrice = <?= $prices->$specialization->Nails ?? 0 ?>;
        var totalPrice = document.querySelector('#totalPrice');
        var totalPriceInteger = parseInt(totalPrice.innerHTML, 10);

        if (nails.checked) {
            totalPriceInteger += nailsPrice;
        }
        else
            totalPriceInteger -= nailsPrice;

        document.getElementById('totalPrice').innerHTML = totalPriceInteger;
        document.getElementById('inputTotalPrice').value = totalPriceInteger;
    }
    function checkMoroco() {
        var moroco = document.querySelector("#moroco");
        var morocoPrice = <?= $prices->$specialization->Moroccan_bath ?? 0 ?>;
        var totalPrice = document.querySelector('#totalPrice');
        var totalPriceInteger = parseInt(totalPrice.innerHTML, 10);

        if (moroco.checked) {
            totalPriceInteger += morocoPrice;
        }
        else
            totalPriceInteger -= morocoPrice;

        document.getElementById('totalPrice').innerHTML = totalPriceInteger;
        document.getElementById('inputTotalPrice').value = totalPriceInteger;
    }
    function checkMassage() {
        var mass = document.querySelector("#mass");
        var massPrice = <?= $prices->$specialization->Massage ?? 0 ?>;
        var totalPrice = document.querySelector('#totalPrice');
        var totalPriceInteger = parseInt(totalPrice.innerHTML, 10);

        if (mass.checked) {
            totalPriceInteger += massPrice;
        }
        else
            totalPriceInteger -= massPrice;

        document.getElementById('totalPrice').innerHTML = totalPriceInteger;
        document.getElementById('inputTotalPrice').value = totalPriceInteger;
    }


</script>
<script src="../assets/JavaScript/all.min.js"></script>
<script src="../assets/JavaScript/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <!-- <script src="../assets/JavaScript/script.js"></script> -->
</body>
</html>

