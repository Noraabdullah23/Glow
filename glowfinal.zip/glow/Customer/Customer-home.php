<?php include "header.php"; ?>
    <section class="home w-100" style="padding: 0;">
        <div class="container">
            <div class="row">
                <div class="title">
                    <h1>Customer Page</h1>
                </div>
                <div class="welcome">
                    <h1>Welcome <?= $_SESSION['name'] ?></h1>
                </div>
            </div>
        </div>
        <!--Start footer  -->
        <div class="footer w-100">
            <div class="container-fluid d-flex justify-content-center">
                <p>Copyright &copy; 2023 GLOW</p>
            </div>
        </div>
        <!--End footer  -->
    </section>
<?php include "footer.php"; ?>