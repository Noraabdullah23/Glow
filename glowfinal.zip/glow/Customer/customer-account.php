<?php include "header.php"; ?>
    <section class="account w-100" style="padding: 0;">
        <div class="container" style="min-height: 100vh; display: flex; flex-direction: column;">
            <div class="row">
                <div class="title">
                    <h1 class="test-color">Personal Information</h1>
                </div>
            </div>
            <div class="row">
                <div class="col d-flex justify-content-center">
                    <div class="card w-75 all-content">
                        <div class="card-body pt-3">
                            <!-- Bordered Tabs -->
                            <ul class="nav nav-tabs nav-tabs-bordered">
                                <li class="nav-item eoverview">
                                    <button class="nav-link active" data-bs-toggle="tab"
                                            data-bs-target="#profile-overview">Overview
                                    </button>
                                </li>
                                <li class="nav-item eprofile">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">
                                        Edit Profile
                                    </button>
                                </li>
                            </ul>
                            <div class="tab-content pt-2">
                                <div class="tab-pane fade show active profile-overview" id="profile-overview">
                                    <h5 class="card-title">Profile Details:</h5>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label ">User Name:</div>
                                        <div class="col-lg-9 col-md-8"><?= $_SESSION['username'] ?></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label ">Full Name:</div>
                                        <div class="col-lg-9 col-md-8"><?= $_SESSION['name'] ?></div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Customer ID:</div>
                                        <div class="col-lg-9 col-md-8"><?= $_SESSION['id'] ?></div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Email:</div>
                                        <div class="col-lg-9 col-md-8"><?= $_SESSION['email'] ?></div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Phone Number</div>
                                        <div class="col-lg-9 col-md-8"><?= $_SESSION['phone'] ?></div>
                                    </div>
                                </div>
                                <div class="tab-pane fade profile-edit pt-3" id="profile-edit">
                                    <!-- Profile Edit Form -->
                                    <form action="../php/customer/profile.php" method="post" enctype="multipart/form-data">
                                        <div class="row mb-3">
                                            <label for="ID" class="col-md-4 col-lg-3 col-form-label">Customer
                                                ID</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="id" type="number" class="form-control" id="ID"
                                                       value="<?= $_SESSION['id'] ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="" class="col-md-4 col-lg-3 col-form-label">Full Name</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="name" type="text" class="form-control" id=""
                                                       value="<?= $_SESSION['name'] ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="" class="col-md-4 col-lg-3 col-form-label">User Name</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="username" type="text" class="form-control" id="#" value="<?= $_SESSION['username'] ?>"
                                                       required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="email"
                                                   class="col-md-4 col-lg-3 col-form-label">Email</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="email" type="email" class="form-control" id="email"
                                                       value="<?= $_SESSION['email'] ?>"
                                                       required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="Phone"
                                                   class="col-md-4 col-lg-3 col-form-label">Phone</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="phone" type="tel" minlength="10" maxlength="10" pattern="\d*" class="form-control" id="Phone"
                                                       value="<?= $_SESSION['phone'] ?>" required>
                                            </div>
                                        </div>

                                        <div class="row mb-3" style="position: relative">
                                            <label for="password"
                                                   class="col-md-4 col-lg-3 col-form-label">Password</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input type="password" name="password" class="form-control password-input"
                                                       id="password">
                                                <i id="eye" onclick="showpassword()" class="toggle-password fa fa-eye"></i>
                                                <input type="hidden" value="<?= $_SESSION['password'] ?>" name="oldPassword">
                                            </div>
                                        </div>
                                        <div class="row mb-3" style="position: relative">
                                            <label for="c_password" class="col-md-4 col-lg-3 col-form-label">Confirm
                                                Password</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input type="password" name="c_password" class="form-control password-input1"
                                                       id="c_password">
                                                <i id="eye" onclick="showpassword1()" class="toggle-password1 fa fa-eye"></i>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="text-center">
                                            <button type="submit" name="update" class="btn btn-secondary">Save Changes</button>
                                        </div>
                                    </form><!-- End Profile Edit Form -->
                                </div>
                            </div><!-- End Bordered Tabs -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Start footer  -->
        <div class="footer">
            <div class="container-fluid d-flex justify-content-center">
                <p>Copyright &copy; 2023 GLOW</p>
            </div>
        </div>
        <!--End footer  -->
    </section>
<?php include "footer.php"; ?>