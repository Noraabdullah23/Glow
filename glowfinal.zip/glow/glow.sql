-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2023 at 06:56 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `glow`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `username`, `email`, `password`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `username`, `email`, `phone`, `password`) VALUES
(1, 'customer', 'customer', 'customer@gmail.com', '0545145465', '123');

-- --------------------------------------------------------

--
-- Table structure for table `login_history`
--

CREATE TABLE `login_history` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `login_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login_history`
--

INSERT INTO `login_history` (`id`, `customer_id`, `login_date`) VALUES
(1, 1, '2023-02-05 08:24:PM'),
(2, 1, '2023-02-05 08:26:PM'),
(3, 1, '2023-02-14 07:07:PM'),
(4, 1, '2023-02-14 07:13:PM'),
(5, 1, '2023-02-14 07:31:PM'),
(6, 1, '2023-02-14 07:34:PM');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `serviceProviderId` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `service_name` varchar(255) NOT NULL,
  `clients_number` int(11) NOT NULL DEFAULT 1,
  `type` varchar(255) NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `cardHolderName` varchar(255) NOT NULL,
  `cardNumber` varchar(255) NOT NULL,
  `expireDate` varchar(255) NOT NULL,
  `CVV` varchar(12) NOT NULL,
  `totalPrice` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `serviceProviderId`, `customer_id`, `client_name`, `service_name`, `clients_number`, `type`, `datetime`, `cardHolderName`, `cardNumber`, `expireDate`, `CVV`, `totalPrice`, `status`) VALUES
(1, 1, 1, 'customer', '[\"bride\",\"ordinary\"]', 3, 'in door', '2023-02-08 12:26 PM', '545646545', 'name', '2023-12-31', '555', 700, 2);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `rate` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `serviceProviderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `service_provider`
--

CREATE TABLE `service_provider` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `instaAccount` varchar(255) NOT NULL,
  `snapAccount` varchar(255) NOT NULL,
  `whatsappAccount` varchar(255) NOT NULL,
  `scope` varchar(255) NOT NULL,
  `dayFrom` varchar(255) NOT NULL,
  `dayTo` varchar(255) NOT NULL,
  `timeFrom` varchar(255) NOT NULL,
  `timeTo` varchar(255) NOT NULL,
  `cardName` varchar(255) NOT NULL,
  `accountNumber` varchar(255) NOT NULL,
  `iban` varchar(255) NOT NULL,
  `specialization` varchar(255) NOT NULL,
  `price` text NOT NULL,
  `accepted` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `service_provider`
--

INSERT INTO `service_provider` (`id`, `name`, `username`, `phone`, `email`, `password`, `instaAccount`, `snapAccount`, `whatsappAccount`, `scope`, `dayFrom`, `dayTo`, `timeFrom`, `timeTo`, `cardName`, `accountNumber`, `iban`, `specialization`, `price`, `accepted`) VALUES
(1, 'service', 'service', '0546654621', 'service@gmail.com', '123', 'insta@gmail.com', 'snap@gmail.com', '0545646564', '[\"ex\",\"in\"]', 'Monday', 'Thursday', '11:00 AM', '05:00 PM', 'name', '465465465', '546546546546', '[\"Makeupartist\",\"Hairstylest\"]', '{\"Makeupartist\":{\"Bride\":\"100\",\"Ordinary\":\"200\"},\"Hairstylest\":{\"Bride\":\"500\",\"Ordinary\":\"800\"},\"Spa\":{\"Nails\":\"\",\"Moroccan_bath\":\"\",\"Massage\":\"\"}}', 1),
(2, 'klasd', 'ajsdlasj', '0541256465', 'ajsdghj@gmail.com', '123', 'insta@gmail.com', 'snap@gmail.com', '0545646564', '[\"ex\",\"in\"]', 'Monday', 'Thursday', '05:29 AM', '05:30 PM', 'sajdk', '54646546', '564564564', '[\"Makeupartist\",\"Hairstylest\"]', '{\"Makeupartist\":{\"Bride\":\"500\",\"Ordinary\":\"150\"},\"Hairstylest\":{\"Bride\":\"444\",\"Ordinary\":\"666\"},\"Spa\":{\"Nails\":\"\",\"Moroccan_bath\":\"\",\"Massage\":\"\"}}', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_history`
--
ALTER TABLE `login_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_provider`
--
ALTER TABLE `service_provider`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `login_history`
--
ALTER TABLE `login_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `service_provider`
--
ALTER TABLE `service_provider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
