<?php include "header.php";
$serviceProviderId= $_GET['serviceProviderId'];
$reviews = $database->Select("select c.name,r.comment,r.rate FROM reviews as r ,customer as c WHERE  c.id = r.customer_id  AND serviceProviderId = '$serviceProviderId'");
?>
<!-- Start Section Service -->
<section class="makup">
    <div class="container">
        <div class="title">
            <h1>Testimonials</h1>
        </div>
        <div class="row">
            <div class="slide-container swiper">
                <div class="slide-content">
                    <div class="card-wrapper swiper-wrapper">
                        <?php if(!empty($reviews)){foreach ($reviews as $review ){?>
                            <div class="card3 swiper-slide">
                                <div class="image3-content">
                                    <div class="card3-image">
                                        <img src="assets/Images/p1.png" alt="" class="card-img"/>
                                    </div>
                                </div>

                                <div class="card3-content">
                                    <h4 class="name"><?= $review['name'] ?></h4>
                                    <div class="stars">
                                        <?php
                                            $rateValue = $review['rate'];
                                            for ($i = 1; $i <= 5; $i++) {
                                                if ($i <= $rateValue)
                                                    echo '<i class="fas fa-star"> </i>';
                                                else
                                                    echo '<i class="far fa-star"> </i>';

                                            }
                                        ?>
                                    </div>
                                    <p class="description">
                                        <?= $review['comment'] ?>
                                    </p>
                                </div>
                            </div>
                        <?php } } ?>
                    </div>
                </div>

                <div class="swiper-button-next swiper-navBtn"></div>
                <div class="swiper-button-prev swiper-navBtn"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>
</section>
<!-- End Section Service -->

<!--Start footer  -->
<div class="footer">
    <div class="container-fluid d-flex justify-content-center">
        <p>Copyright &copy; 2023 GLOW</p>
    </div>
</div>
<!--End footer  -->

<script src="assets/JavaScript/all.min.js"></script>
<script src="assets/JavaScript/bootstrap.bundle.min.js"></script>
<script src="assets/JavaScript/swiper-bundle.min.js"></script>
<script src="assets/JavaScript/script2.js"></script>
</body>
</html>
