<?php include "header.php"; ?>
<!-- Start Section About -->
<section class="about">
    <div class="container">
        <div class="row all-content">
            <div class="image col">
                <img src="assets/Images/Aboutus.jpeg"/>
            </div>

            <div class="content col">
                <h2>About Us</h2>
                <span><!-- line here --></span>
                <p>
                    We were founded in 2022 by six students in KFU with the idea of
                    providing beauty needs in one location, saving customers time, and
                    making them feel beautiful. At that time, Glow website was the
                    first website to combine a full-service salon and spa within a
                    dynamic website .
                </p>

                <ul class="social-icons">
                    <li>
                        <a href=""><i class="fa-brands fa-twitter"></i></a>
                    </li>
                    <li>
                        <a href=""><i class="fa-brands fa-whatsapp"></i></a>
                    </li>
                    <li>
                        <a href=""><i class="fa-brands fa-instagram"></i></a>
                    </li>
                    <li>
                        <a href=""><i class="fa-brands fa-snapchat"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!-- End Section About -->

<!-- Start Section Mision -->
<section class="mision mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Vision</h5>
                        <p class="card-text">
                            our mission is to be best service provider that gives many
                            different selections of hairstylists, makeup artists, and SPA
                            services with diversity of prices which will facilitate searching
                            process for customers
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Mission</h5>
                        <p class="card-text">
                            Our mission statement at Glow is to provide all kinds of salon
                            services in one place to turn art into beauty through professional
                            service providers. As well as enabling the customer to book
                            immediately without wasting time or needing human intervention
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Values</h5>
                        <p class="card-text">
                        <ul>
                            <li>professionalism</li>
                            <li>Accountability</li>
                            <li>Efficiency</li>
                        </ul>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Section Mision -->

<!--Start footer  -->
<div class="footer">
    <div class="container-fluid d-flex justify-content-center">
        <p>Copyright &copy; 2023 GLOW</p>
    </div>
</div>
<!--End footer  -->

<script src="assets/JavaScript/all.min.js"></script>
<script src="assets/JavaScript/bootstrap.bundle.min.js"></script>
<script src="assets/JavaScript/script.js"></script>
<script src="assets/JavaScript/swiper-bundle.min.js"></script>

</body>
</html>
