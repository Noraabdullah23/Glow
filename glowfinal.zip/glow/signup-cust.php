<?php include "header.php"; ?>
<!-- Start Section Log in -->
<section class="login">
    <div class="container">
        <div class="row">
            <div class="title">
                <h4>Registration for (customer)</h4>
            </div>
            <form action="php/generalRegister.php" method="post">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Full Name</label>
                    <input type="text" name="name" required class="form-control" aria-describedby="emailHelp" placeholder="Your Name..."/>
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">User Name</label>
                    <input type="text" name="username" required class="form-control" aria-describedby="emailHelp" placeholder="Your User Name..."/>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Enter your phone number</label>
                    <input type="text" name="phone" required class="form-control" aria-describedby="emailHelp" placeholder="05.." maxlength="10" minlength="10" pattern="\d*"/>
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Enter your Email</label>
                    <input type="email" name="email" required class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="your email.."/>
                </div>
                <div class="mb-3" style="position: relative">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" name="password" required class="form-control password-input1" id="exampleInputPassword1" placeholder="Password" minlength="8"/>
                    <i id="eye" onclick="showpassword1()" class="toggle-password1 fa fa-eye"></i>
                </div>
                <div class="mb-3" style="position: relative">
                    <label for="exampleInputPassword1" class="form-label">Confirm Password</label>
                    <input type="password" name="c_password" required class="form-control password-input" id="exampleInputPassword1" placeholder="Password"/>
                    <i id="eye" onclick="showpassword()" class="toggle-password fa fa-eye"></i>
                </div>
                <div class="form-text mb-3 mt-3 swich">
                    <input type="checkbox" id="checkbox" required name="checkbox">
                    <label for="checkbox"> I agree to all <a href="condition.php">the terms and conition </a>
                </div>
                <button type="submit" name="registerCustomer" class="btn btn-primary w-100 sub" style="background-color: #bf978f; border: none">
                    Sign up
                </button>
            </form>
        </div>
    </div>
</section>
<!-- End Section Log in -->

<!--Start footer  -->
<div class="footer">
    <div class="container-fluid d-flex justify-content-center">
        <p>Copyright &copy; 2023 GLOW</p>
    </div>
</div>
<!--End footer  -->

<script src="assets/JavaScript/all.min.js"></script>
<script src="assets/JavaScript/bootstrap.bundle.min.js"></script>
<script src="assets/JavaScript/script.js"></script>
</body>
</html>
