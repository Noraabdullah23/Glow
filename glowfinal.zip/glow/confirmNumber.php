<?php include "header.php"; ?>
<!-- Start Section Log in -->
<section class="login">
    <div class="container">
        <div class="row">
            <div class="title">
                <h4>confirm your phone number</h4>
            </div>
            <form>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Phone Number</label>
                    <input type="text" name="username" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Your phone number" maxlength="10"/>
                </div>
                <button type="button" onclick="alert('your new password has been sent to your phone number')" name="loginBtn" class="btn btn-primary w-100 sub" style="background-color: #bf978f; border: none">send new password</button>
            </form>
        </div>
    </div>
</section>
<!-- End Section Log in -->

<!--Start footer  -->
<div class="footer">
    <div class="container-fluid d-flex justify-content-center">
        <p>Copyright &copy; 2023 GLOW</p>
    </div>
</div>
<!--End footer  -->

<script src="assets/JavaScript/all.min.js"></script>
<script src="assets/JavaScript/bootstrap.bundle.min.js"></script>
<script src="assets/JavaScript/script.js"></script>
</body>
</html>
