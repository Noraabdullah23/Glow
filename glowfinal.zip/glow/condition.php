<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>terms and condition</title>

    </head>
    <body>
        <h1>terms and condition</h1>
        <h3>Insurance</h3>
        <p>We believes the customer is always right. With our industry having no regulations it is up to us to set
            standards and keep ahead of the professionals. All of our staff are fully qualified in all treatments they carry out.
            We have a salon policy for individual professional indemnity insurance, public and product liability and employer’s
            liability. Our current insurance is with Towergate and underwritten by AXA
            All certificates are kept in the ‘Meet our Team’ folder in reception and individual files located in the safe. These can
            be viewed by anyone who wishes to see them.</p>
        <h3>Health and safety </h3>
        <p> Salon glow is, of course, the utmost importance and to achieve optimal cleanliness all our sterilisation
            equipment is approved by the local Environmental Health Officer.
            Womankind Beauty takes health and safety very seriously. We have a full policy set out in our salon folder along
            with a risk assessment and fire risk assessment and Covid 19 risk assessment.
            In the Interest of client safety all vulnerable people will be taken in salon 1 this includes anyone with a disability or
            under the age of 16.
            Should a fire occur do not delay exiting the building via the front door.
            We operate a recycling policy within the premises in line with waste Scotland and government legislation.        </p>
        <h3>Punctuality and Courtesy </h3>
        <p>Arriving late may interfere with your treatment. All appointments will end at their scheduled time, so that the next
            client will not be delayed, and a full charge will be applied. All times stated include preparation of room and client:
            i.e. 5 minutes at the beginning and end of treatment.
            Please arrive 10 minutes prior to treatment if it is your first appointment at the salon. We require this time for you
            to complete a personal consultation card, this document is 100% confidential and is used for treatment purposes
            only.</p> 
        <h3>Services and price list         </h3>
        <p>All services and prices may be subject to change. For our latest prices and services please check our website.
            Treatment times can include consultation, dressing and undressing time. Please ask for details. </p>
        <h3>Cancellations         </h3>
        <p>Please note 24 Hours notice is required for all cancellations, otherwise the total treatment price will be charged.
            Cancellations should be made by calling us on 0576975809 or email glow@hotmail.com
            For repeat offenses of ‘no show’ appointments clients will have to prepay their appointments at the time of
            booking.
            For visits over 1 hour a 50% deposit will be required at the time of booking. This can be changed to another
            appointment or refunded when the correct cancelation notice is given of 24 hours. For cancelations withing 24
            hours of booking time or “no show“ appointments would result in the loss of 50% deposit.
            For visits party and home bookings a 50% deposit will be required at the time of booking. full payment may be
            required 48 hours before your scheduled appointment. Cancelations within 48 hours will require full payment.
            Cancellations within 7 days will incur the loss of the 50% deposit. . </p> 
        <h3>The information we collect and how        </h3>
        <p>At Womankind Beauty we take privacy seriously and only use the information we collect to provide our services.
            We do not share or sell the information we collect for any other purpose than providing the best possible service
            for our clients. At any time, you may request a copy of information we have recorded about you. You may also
            request we remove all identifiable information with respect to yourself. As a matter of course, we will delete your
            identifiable information if you have not undertaken business with us after 2 years.
            For transparency, listed are the business services we provide and how each service uses the information we
            collect. Beauty related services:
            We request the minimum level of personally identifying information to run our business effectively. This is data
            you provide us directly, for example, your name and contact details. We will never obtain information about you
            indirectly from sources outside our business. We store notes with respect to services we undertake to ensure we
            maintain and exceed our level of service. For example, your preferred colour formula codes, how you like your
            coffee and who your favourite therapists are. We consider you have provided consent for us to store personally
            identifying information and information about your services based on your receiving services from us. Depending
            on the particular service(s) we are providing we may be required to ask questions related to your medical history.
            We will obtain your consent prior to storing information related to your medical history. Examples of medical data
            may be allergies, pregnancy or an injury that may impact our service.
            Appointment confirmations and reminders:
            We will contact you via phone, email or SMS to confirm appointments booked and remind you of upcoming
            appointments. We consider your having made the appointment as consent to undertake this activity but, if you
            want, you may opt-out at any time.
            Appointment ratings and reviews:
            After visiting us we may send you an email or SMS asking you to rate our services and provide feedback. We
            consider your agreement and participation in the service as consent to undertake this activity but, if you want, you
            may opt out at any time.
            Loyalty:
            We consider becoming a member of our loyalty program as consent to send you emails related to the loyalty
            program but, if you want, you may opt out at any time.
            Marketing:
            We will not undertake phone, mail, email or SMS marketing without you first providing consent for us to do so.
            Our marketing campaigns are automated and use rules based on services and products purchased and information
            we collect from you. For example, we may send marketing campaigns related to your birthday, the fact we miss
            you (you have not visited for 3 months) and other special days like Valentine’s Day and Christmas. Of course, you
            may opt out of receiving marketing material at any time.
            Data processors and data locations:
            We use numerous leading software solutions within our business to provide the services listed above. These
            software solutions store and process data in numerous locations outside our business premise. For a list of
            software providers and data storage locations please visit: www.saloniris.com
            You may contact us at womankindbeauty@live.co.uk to: • Request a discussion about our Privacy Policy.
            • Request information we have stored about you.
            • Request we remove all identifying information about you.
            • Make a complaint.</p> 
        <h3>Payment</h3>
        <p>Most credit and debit Cards are accepted, or cash. All prices include value added tax at a current rate.
            We use online payments through Stripe.
            Bookings that are 1 hour or more require 50% deposit will be required at the time of booking and full payment will
            be required 48 hours before scheduled appointment. Cancelations within 24 hours will require full payment.
            Cancellations within 48 days will incur the loss of the 50% deposit.</p> 
        <h3>Copyright Notice         </h3>
        <p>All design, text, graphics and arrangement thereof are the copyright of womankind Beauty or of other copyright
            owners. Any unauthorised reproduction of the contents of this site without the prior written permission of
            womankind Beauty is strictly prohibited. </p> 
        <h3></h3>
        <p></p> 
        <h3></h3>
        <p></p> 
        <h3></h3>
        <p></p> 
        <h3></h3>
        <p></p> 
        <h3></h3>
        <p></p> 
        <h3></h3>
        <p></p>
    </body>
</html>