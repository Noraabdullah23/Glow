<?php include "header.php"; ?>
<!-- Strat Section FAQ -->
<section class="faq" style="font-family: monospace">
    <div class="container">
        <div class="row">
            <div class="faq-wrapper">
                <div class="header2">
                    <h1>FAQs</h1>
                </div>
                <div class="faq-inner">
                    <div class="faq-item">
                        <h3>
                            What is glow and how does it work ?
                            <span class="faq-plus">&plus;</span>
                        </h3>
                        <div class="faq-body">
                            It is a website brings together beauty service providers, it
                            works by booking a services In order to help the ladies in the
                            quick booking of their happy occasions .
                        </div>
                    </div>
                    <hr/>
                    <div class="faq-item">
                        <h3>
                            What are the servises provide by glow site ?
                            <span class="faq-plus">&plus;</span>
                        </h3>
                        <div class="faq-body">
                            Glow website provide a (hairstyle , makeup artists, and SPA ).
                        </div>
                    </div>
                    <hr/>
                    <div class="faq-item">
                        <h3>
                            how can i book ?
                            <span class="faq-plus">&plus;</span>
                        </h3>
                        <div class="faq-body">
                            After you sign in , choose your required service, the add your
                            required information , then payment, after that you
                            successfully booking a service in our website.
                        </div>
                    </div>
                    <hr/>
                    <div class="faq-item">
                        <h3>
                            can i change my book ?
                            <span class="faq-plus">&plus;</span>
                        </h3>
                        <div class="faq-body">
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the industry's
                            standard dummy text ever since the 1500s, when an unknown
                            printer took a galley of type and scrambled it to make a type
                            specimen book.
                        </div>
                    </div>
                    <hr/>
                    <div class="faq-item">
                        <h3>
                            What is the payment method ?
                            <span class="faq-plus">&plus;</span>
                        </h3>
                        <div class="faq-body">Credit card</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Section FAQ -->

<!-- Start footer -->
<div class="footer">
    <div class="container-fluid d-flex justify-content-center">
        <p>Copyright &copy; 2023 GLOW</p>
    </div>
</div>
<!--End footer -->
<script type="text/javascript">
    $(".faq-plus").on("click", function () {
        $(this).parent().parent().find(".faq-body").slideToggle();
    });
</script>
<script src="assets/JavaScript/all.min.js"></script>
<script src="assets/JavaScript/bootstrap.bundle.min.js"></script>
<script src="assets/JavaScript/script.js"></script>
</body>
</html>
