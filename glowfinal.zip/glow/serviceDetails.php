<?php include "header.php";
$specialization = $_GET['specialization'];
$serviceProviders = $database->Select("select * from service_provider WHERE specialization LIKE '%$specialization%'");
?>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@1,700&display=swap');
</style>
<!-- Start Section Service -->
<section class="makup">
    <div class="container">
        <div class="title">
            <h1>Our <?= $_GET['specialization'] ?></h1>
        </div>
        <?php if(!empty($serviceProviders)){ ?>
            <div class="row">
                <div class="slide-container swiper">
                    <div class="slide-content">
                        <div class="card-wrapper swiper-wrapper">
                            <?php foreach ($serviceProviders as $provider){ ?>
                                <div class="card2 swiper-slide">
                                    <div class="image2-content">
                                        <div class="card2-image">
                                            <h2 style="font-family: 'Playfair Display', serif; font-size:35px; font-weight: 700;"><?= $provider['name'] ?></h2>
                                        </div>
                                    </div>

                                    <div class="card2-content">
                                        <ul class="social-icons6" style = "display: flex; gap: 10px; padding:0;">
                                            <li style = "list-style: none;">
                                                <a href="" onclick="alert('whatsapp Account is <?= $provider["whatsappAccount"] ?>')"><i class="fa-brands fa-whatsapp"></i></a>
                                            </li>
                                            <li style = "list-style: none;">
                                                <a href="<?= $provider['instaAccount'] ?>"><i class="fa-brands fa-instagram"></i></a>
                                            </li>
                                            <li style = "list-style: none;">
                                                <a href="<?= $provider['snapAccount'] ?>"><i class="fa-brands fa-snapchat"></i></a>
                                            </li>
                                        </ul>
                                        <a class="review" href="testimonials.php?serviceProviderId=<?= $provider['id']?>">Reviews</a>
                                        <div class="stars">
                                            <?php
                                                $serviceProviderId = $provider['id'];
                                                $rate = $database->Select("Select AVG(rate) from reviews WHERE serviceProviderId = '$serviceProviderId'");
                                                if(!empty($rate)) {
                                                    $rateValue = $rate[0][0];
                                                    for ($i = 1; $i <= 5; $i++) {
                                                        if ($i <= $rateValue)
                                                            echo '<i class="fas fa-star"> </i>';
                                                        else
                                                            echo '<i class="far fa-star"> </i>';

                                                    }
                                                }
                                            ?>
                                        </div>
                                        <p class="port"><?= $provider['name'] ?></p>
                                        <p class="description">Do <?php if($_GET['specialization']=='Makeupartist'){echo 'makeUp';}else if($_GET['specialization']=='Hairstylest'){echo 'hair';}else{echo 'Spa';}  ?> In ALHASSA</p>
                                        <?php if(isset($_SESSION['user_type'])&&$_SESSION['user_type']=='customer'){ ?>
                                            <a class="button" href="Customer/booking.php?specialization=<?= $_GET['specialization'] ?>&serviceId=<?= $provider['id'] ?>" style="text-decoration: none; color: white">Book</a>

                                        <?php }else{ ?>
                                            <h5><a href="signin.php">login</a> before you book</h5>
                                        <?php } ?>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>

                    <div class="swiper-button-next swiper-navBtn"></div>
                    <div class="swiper-button-prev swiper-navBtn"></div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        <?php } else{ ?>
            <h3 class="text-center p-5 m-5">No <?= $_GET['specialization'] ?> </h3>
        <?php } ?>
    </div>
</section>
<!-- End Section Service -->

<!--Start footer  -->
<div class="footer">
    <div class="container-fluid d-flex justify-content-center">
        <p>Copyright &copy; 2023 GLOW</p>
    </div>
</div>
<!--End footer  -->

<script src="assets/JavaScript/all.min.js"></script>
<script src="assets/JavaScript/bootstrap.bundle.min.js"></script>
<script src="assets/JavaScript/swiper-bundle.min.js"></script>
<script src="assets/JavaScript/script2.js"></script>
</body>
</html>
