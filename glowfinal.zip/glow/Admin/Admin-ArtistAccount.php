<?php include "header.php";
$serviceProviders = $database->Select("Select * from service_provider");
?>
    <!-- Start Artist Account     -->
    <section class="artist w-100" style="padding: 0;">
        <div class="container-fluid p-0"
             style="display: flex; flex-direction: column; align-items: center; justify-content: center;padding-top: 3rem;min-height: 100vh">
            <div class="row">
                <div class="title">
                    <h1 class="test-color">Artist Account</h1>
                </div>
            </div>
            <div class="row mb-2" style="width: 100%!important">
                <table id="example" class="table table-striped test-color" style="width:100%">
                    <thead class="test-color">
                    <tr class="test-color">
                        <th style="text-align: center;">Provider Id</th>
                        <th style="text-align: center;">User Name</th>
                        <th style="text-align: center;">Name</th>
                        <th style="text-align: center;">Email</th>
                        <th style="text-align: center;">Phone Number</th>
                        <th style="text-align: center;">Password</th>
                        <th style="text-align: center;">Social account</th>
                        <th style="text-align: center;">Control</th>
                    </tr>
                    </thead>
                    <tbody class="test-color">
                    <?php if (!empty($serviceProviders)) {
                        foreach ($serviceProviders as $provider) { ?>
                            <tr class="test-color">
                                <td class="test-color"><?= $provider['id'] ?></td>
                                <td><?= $provider['username'] ?></td>
                                <td><?= $provider['name'] ?></td>
                                <td><?= $provider['email'] ?></td>
                                <td><?= $provider['phone'] ?></td>
                                <td><?= $provider['password'] ?></td>
                                <td><?= $provider['instaAccount'] ?></td>
                                <td class="text-center">
                                    <?php if ($provider['accepted'] == 0) { ?>
                                        <button class="btn btn-outline-success test-color" onclick="Accept(<?= $provider['id'] ?>)">
                                            Accept
                                            <i class="fa-regular fa-circle-check"></i>
                                        </button>
                                        <button class="btn btn-outline-danger test-color" onclick="Refuse(<?= $provider['id'] ?>)">
                                            Refuse
                                            <i class="fa-regular fa-circle-xmark"></i>
                                        </button>
                                    <?php } else if ($provider['accepted'] == 2) {
                                        echo 'Refused';
                                    } else {
                                        echo 'Accepted';
                                    } ?>
                                </td>
                            </tr>
                        <?php }
                    } ?>
                    </tbody>
                </table>
            </div>
            <!--Start footer  -->
            <div class="footer w-100">
                <div class="container-fluid d-flex justify-content-center">
                    <p>Copyright &copy; 2023 GLOW</p>
                </div>
            </div>
            <!--End footer  -->
        </div>
        <style>
            .cancel{
                background-color: red!important;
                color: white;
            }

        </style>
    </section>
    <!-- End Artist Account     -->
    <script>
        function Accept(id) {
            swal({title:'Are You Sure To Accept ?',
                    showCancelButton: true,
                    confirmButtonText: "Yes",
                    cancelButtonText: "No",
                },
                function (result) {
                    if(result)
                        window.location.href="../php/admin/artistAccept.php?accept="+id;
                }
            )
        }
        function Refuse(id) {
            swal({title:'Are You Sure To Refuse ?',
                    showCancelButton: true,
                    confirmButtonText: "Yes",
                    cancelButtonText: "No",
                },
                function (result) {
                    if(result)
                        window.location.href="../php/admin/artistAccept.php?refuse="+id;
                }
            )
        }
    </script>
<?php include "footer.php"; ?>