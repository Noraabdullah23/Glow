<?php include "header.php";
$loginHistories=$database->Select("Select customer.*,login_history.login_date,login_history.customer_id from login_history,customer WHERE customer.id = login_history.customer_id");
?>
    <!-- Start Artist Account     -->
    <section class="artist w-100" style="padding: 0;">
        <div class="container-fluid pb-0 p-0"
             style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh;padding-top: 3rem;">
            <div class="row">
                <div class="title">
                    <h1 class="test-color">Customer History</h1>
                </div>
            </div>
            <div class="row mb-2" style="width: 85%!important">
                <table class="test-color" id="example" class="table table-striped" style="width:100%">
                    <thead>
                    <tr>
                        <th style="text-align: center;">Customer Id</th>
                        <th style="text-align: center;">User Name</th>
                        <th style="text-align: center;">Name</th>
                        <th style="text-align: center;">Email</th>
                        <th style="text-align: center;">Phone Number</th>
                        <th style="text-align: center;">Password</th>
                        <th style="text-align: center;">Login Date</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($loginHistories)){foreach ($loginHistories as $history){ ?>
                            <tr>
                                <td><?= $history['customer_id'] ?></td>
                                <td><?= $history['username'] ?></td>
                                <td><?= $history['name'] ?></td>
                                <td><?= $history['email'] ?></td>
                                <td><?= $history['phone'] ?></td>
                                <td><?= $history['password'] ?></td>
                                <td><?= $history['login_date'] ?></td>
                            </tr>
                        <?php } } ?>
                    </tbody>
                </table>
            </div>
            <!--Start footer  -->
            <div class="footer w-100">
                <div class="container-fluid d-flex justify-content-center">
                    <p>Copyright &copy; 2023 GLOW</p>
                </div>
            </div>
            <!--End footer  -->
        </div>

    </section>
<?php include "footer.php"; ?>