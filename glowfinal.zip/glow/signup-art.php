<?php include "header.php"; ?>
<!-- Start Section Log in -->
<section class="login mb-5">
    <div class="container">
        <div class="row">
            <div class="title">
                <h4>Registration for (Services Provider)</h4>
            </div>
            <form action="php/generalRegister.php" method="post">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Full Name</label>
                    <input type="text" name="name" required class="form-control" aria-describedby="emailHelp" placeholder="Your Name..."/>
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">User Name</label>
                    <input type="text" name="username" required class="form-control" aria-describedby="emailHelp" placeholder="Your User Name..."/>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Enter your phone number</label>
                    <input type="text" name="phone" required class="form-control" aria-describedby="emailHelp" placeholder="05.." minlength="10" pattern="\d*" maxlength="10"/>
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Enter your Email</label>
                    <input type="email" name="email" required class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="your email.."/>
                </div>
                <div class="mb-3" style="position: relative">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" name="password" required class="form-control password-input1" id="exampleInputPassword1" placeholder="Password" minlength="8"/>
                    <i id="eye" onclick="showpassword1()" class="toggle-password1 fa fa-eye"></i>
                </div>
                <div class="mb-3" style="position: relative">
                    <label for="exampleInputPassword1" class="form-label">Confirm Password</label>
                    <input type="password" name="c_password" required class="form-control password-input" id="exampleInputPassword1" placeholder="Password"/>
                    <i id="eye" onclick="showpassword()" class="toggle-password fa fa-eye"></i>
                </div>
                <div class="title mt-4">
                    <h4>Social accounts</h4>
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Instgram account</label>
                    <input type="text" name="instaAccount" required class="form-control" aria-describedby="emailHelp" placeholder="@..."/>
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Snap account</label>
                    <input type="text" name="snapAccount" required class="form-control" aria-describedby="emailHelp" placeholder="@..."/>
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Whatsapp account</label>
                    <input type="text" name="whatsappAccount" required class="form-control" aria-describedby="emailHelp" placeholder="@..."/>
                </div>                
                <h5 class="mt-4">The scope of your services:</h5>
                <input type="checkbox" id="external" name="scope[]" value="ex"/>
                <label for="external"> I provid external services</label><br/>
                <input type="checkbox" id="internal" name="scope[]" value="in"/>
                <label for="internal"> I provid internal services</label><br/>
                <div class="mb-3">
                    <h5 class="mt-4">Specialization:</h5>
                    <div class="form-check d-flex justify-content-center  gap-2" style="flex-direction: column;" >
                    <div>
                        <input class="form-check-input" name="specialization[]" type="checkbox" value="Makeupartist" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                            Makeupartist
                        </label>
                    </div>
                        <ul>
                            <li class="mb-2"><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 125px">Bride</span>
                                <input type="number" min="0"  name="price[Makeupartist][Bride]" class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>
                            <li class=""><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 125px">Ordinary</span>
                                <input type="number" min="0"  name="price[Makeupartist][Ordinary]" class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>                            
                        </ul>

                    </div>
                    <div class="form-check d-flex justify-content-center  gap-2" style="flex-direction: column;" >
                    <div>
                        <input class="form-check-input" name="specialization[]" type="checkbox" value="Hairstylest" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                            Hairstylest
                        </label>
                    </div>
                        <ul>
                            <li class="mb-2"><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 125px">Bride</span>
                                <input type="number" min="0"  name="price[Hairstylest][Bride]" class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>
                            <li class=""><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 125px">Ordinary</span>
                                <input type="number" min="0"  name="price[Hairstylest][Ordinary]" class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>                            
                        </ul>

                    </div>
                    <div class="form-check d-flex justify-content-center  gap-2" style="flex-direction: column;" >
                    <div>
                        <input class="form-check-input" name="specialization[]" type="checkbox" value="Spa" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                            Spa
                        </label>
                    </div>
                        <ul>
                            <li class="mb-2"><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 125px">Nails</span>
                                <input type="number" min="0"  name="price[Spa][Nails]"  class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>
                            <li class="mb-2"><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 125px">Moroccan bath</span>
                                <input type="number" min="0"  name="price[Spa][Moroccan_bath]"  class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>
                                <li class=""><div class="d-flex justify-content-center align-items-center gap-2"> <span style="width: 125px">Massage</span>
                                <input type="number" min="0"  name="price[Spa][Massage]"  class="form-control p-1" aria-describedby="emailHelp" placeholder="Price"/>
                            </div></li>                             
                        </ul>

                    </div>                  
                </div>
                <div class="workin-day">
                    <div class="title mt-4">
                        <h4>Working Days</h4>
                    </div>
                    <label for="day1"><h5>From</h5></label>
                    <select id="day1" name="dayFrom" class="form-select" required aria-label="Default select example">
                        <option value="Sunday">Sunday</option>
                        <option value="Monday">Monday</option>
                        <option value="Tuesday">Tuesday</option>
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
                        <option value="Saturday">Saturday</option>
                    </select>
                    <label class="mt-3" for="day2"><h5>To</h5></label>
                    <select id="day2" name="dayTo" class="form-select mb-3" required aria-label="Default select example">
                        <option value="Sunday">Sunday</option>
                        <option value="Monday">Monday</option>
                        <option value="Tuesday">Tuesday</option>
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
                        <option value="Saturday">Saturday</option>
                    </select>
                </div>
                <div class="workin-hour">
                    <div class="title mt-4">
                        <h4>Working Hours</h4>
                    </div>
                    <div class="from">
                        <label for="day1"><h5>From</h5></label>
                        <input type="time" id="appt" required name="timeFrom"/>
                    </div>
                    <div class="to">
                        <label class="mt-3" for="day2"><h5>To</h5></label>
                        <input type="time" id="appt" required name="timeTo"/>
                    </div>
                </div>
                <div class="title mt-2 mb-3">
                    <h4>Banking Information</h4>
                </div>
                <div class="mb-3">
                    <input type="text" class="form-control" required name="cardName" aria-describedby="emailHelp" placeholder="Services provider name (as it appear on credit card)"/>
                </div>
                <div class="mb-3">
                    <input type="text" class="form-control" required name="accountNumber" aria-describedby="emailHelp" placeholder="Account number"/>
                </div>
                <div class="mb-3">
                    <input type="text" class="form-control" required name="iban" aria-describedby="emailHelp" placeholder="Iban (start with SA)" maxlength="24" minlength="24"/>
                </div>
                <div class="form-text mb-3 mt-3 swich">
                    <input type="checkbox" id="checkbox" required name="checkbox">
                    <label for="checkbox"> I agree to all <a href="condition.php">the terms and conition </a>
                </div>
                <button type="submit" name="registerServiceProvider" class="btn btn-primary w-100 sub" style="background-color: #bf978f; border: none">
                    Sign up
                </button>
            </form>
        </div>
    </div>
</section>
<!-- End Section Log in -->

<!--Start footer  -->
<div class="footer">
    <div class="container-fluid d-flex justify-content-center">
        <p>Copyright &copy; 2023 GLOW</p>
    </div>
</div>
<!--End footer  -->

<script src="assets/JavaScript/all.min.js"></script>
<script src="assets/JavaScript/bootstrap.bundle.min.js"></script>
<script src="assets/JavaScript/script.js"></script>
</body>
</html>
