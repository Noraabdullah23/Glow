<?php include "header.php"; ?>
<!-- Start Section Log in -->
<section class="login">
    <div class="container">
        <div class="row">
            <div class="title">
                <h4>log In</h4>
            </div>
            <form action="php/generalLogin.php" method="post">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">User Name</label>
                    <input type="text" name="username" class="form-control" id="exampleInputEmail1"
                           aria-describedby="emailHelp" placeholder="Your User Name..."/>
                </div>
                <div class="mb-3" style="position: relative">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control password-input" id="exampleInputPassword1"
                           placeholder="Password"/>
                        <i id="eye" onclick="showpassword()" class="toggle-password fa fa-eye"></i>
                </div>
                <div class="mb-3">
                    <a href="confirmNumber.php">Forgot password?</a>
                </div>
                <div class="form-text mb-5 mt-3 swich">
                    <p>
                        If you do not have account link Sign up as
                        <a href="signup-cust.php" style="margin-right: 10px">Customer</a>
                        <a href="signup-art.php">Services provider </a>
                    </p>
                </div>
                <button type="submit" name="loginBtn" class="btn btn-primary w-100 sub"
                        style="background-color: #bf978f; border: none">Sign in
                </button>
            </form>
        </div>
    </div>
</section>
<!-- End Section Log in -->

<!--Start footer  -->
<div class="footer">
    <div class="container-fluid d-flex justify-content-center">
        <p>Copyright &copy; 2023 GLOW</p>
    </div>
</div>
<!--End footer  -->


<script src="assets/JavaScript/all.min.js"></script>
<script src="assets/JavaScript/bootstrap.bundle.min.js"></script>
<script src="assets/JavaScript/script.js"></script>
</body>
</html>
